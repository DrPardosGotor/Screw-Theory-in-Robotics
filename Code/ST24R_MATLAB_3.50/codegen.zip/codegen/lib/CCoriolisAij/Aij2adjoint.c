/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: Aij2adjoint.c
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 10-Mar-2019 20:59:05
 */

/* Include Files */
#include <string.h>
#include "CCoriolisAij.h"
#include "Aij2adjoint.h"
#include "mldivide.h"
#include "expScrew.h"
#include "CCoriolisAij_data.h"

/* Function Definitions */

/*
 * Arguments    : double i
 *                double j
 *                const double TwMag[49]
 *                double Ad[36]
 * Return Type  : void
 */
void Aij2adjoint(double i, double j, const double TwMag[49], double Ad[36])
{
  double PoE[16];
  int i6;
  int k;
  double dv1[16];
  int PoE_tmp;
  double b_PoE[16];
  int i7;
  int i8;
  double dv2[9];
  double c_PoE[36];
  double dv3[9];

  /*  "AIJ2ADJOINT" Computes ADJOINT TRANSFORMATION for list of twists-mag. */
  /*  Use in SE(3). */
  /*  Notation useful for Link Jacobian (mobile). */
  /*  Notation useful for Christofell Symbols. */
  /*  Use in SE(3). */
  /*  */
  /*  	Ad = Aij2adjoint(i,j,TwMag) */
  /*  */
  /*  INPUTS: */
  /*  TwMag = [Tw1; Mag1, ..., Twn; Magn] (7xn) */
  /*  for each rigid body joint (link 1..n). */
  /*  Twn1..Twn6: The TWIST components for the joint SCREW movement. */
  /*  Magn: The MAGNITUDE component for the joint SCREW movement. */
  /*  */
  /*  ADJOINT TRANSFORMATION: This is a special notation which gives us a most  */
  /*  form of the Adjoint of an open chain manipulator */
  /*  We use this notation for an easy calculation of the Manipulator Inertia  */
  /*  Matrix and the Manipulator Coriolis Matrix.  */
  /*  Computes the Adg in R^6 (6x6 matrix) from any robot link. */
  /*       I                                    if i=j  */
  /*  Aij= Ad^-1[(exp(Ej+1,Tj+1)...(exp(Ei,Ti)] if i>j */
  /*       0                                    if i<j */
  /*  */
  /*  See also: tform2adjoint, expScrew. */
  /*  */
  /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
  /*  */
  /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
  /*   */
  /*  ST24R is free software: you can redistribute it and/or modify */
  /*  it under the terms of the GNU Lesser General Public License as published */
  /*  by the Free Software Foundation, either version 3 of the License, or */
  /*  (at your option) any later version. */
  /*   */
  /*  ST24R is distributed in the hope that it will be useful, */
  /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
  /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
  /*  GNU Lesser General Public License for more details. */
  /*   */
  /*  You should have received a copy of the GNU Leser General Public License */
  /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
  /*  */
  /*  http://www. */
  /*  */
  /*  CHANGES: */
  /*  Revision 1.1  2019/02/11 00:00:01 */
  /*  General cleanup of code: help comments, see also, copyright */
  /*  references, clarification of functions. */
  /*  */
  /*  	Ad = Aij2adjoint(i,j,TwMag) */
  /*  */
  memset(&Ad[0], 0, 36U * sizeof(double));
  if (!(i < j)) {
    if (i == j) {
      for (i6 = 0; i6 < 36; i6++) {
        Ad[i6] = iv0[i6];
      }
    } else {
      expScrew(*(double (*)[7])&TwMag[7 * ((int)(j + 1.0) - 1)], PoE);
      i6 = (int)(i + (1.0 - (j + 2.0)));
      for (k = 0; k < i6; k++) {
        expScrew(*(double (*)[7])&TwMag[7 * ((int)((j + 2.0) + (double)k) - 1)],
                 dv1);
        for (PoE_tmp = 0; PoE_tmp < 4; PoE_tmp++) {
          for (i7 = 0; i7 < 4; i7++) {
            i8 = i7 << 2;
            b_PoE[PoE_tmp + i8] = ((PoE[PoE_tmp] * dv1[i8] + PoE[PoE_tmp + 4] *
              dv1[1 + i8]) + PoE[PoE_tmp + 8] * dv1[2 + i8]) + PoE[PoE_tmp + 12]
              * dv1[3 + i8];
          }
        }

        memcpy(&PoE[0], &b_PoE[0], sizeof(double) << 4);
      }

      /*  */
      /*  "TFORM2ADJOINT" Find the adjoint matrix associated with a tform. */
      /*  Use in SE(3). */
      /*  */
      /*  	Ad = tform2adjoint(tform) */
      /*  */
      /*  ADJOINT TRANSFORMATION: */
      /*  it is used to transforms twist from one coordinate frame to another. */
      /*  Vs =Adg*Vb ; Vac = Adgab*Vbc ; E'=Adg*E */
      /*  The adjoint transformation maps twist vectors to twist vectors. */
      /*  Compute the Adg in R^6 (6x6 matrix9 from the homogeneous matrix g 4x4. */
      /*       |R p^R|            |R p| */
      /*  Adg =|     | <= tform = |   | */
      /*       |0   R|            |0 1| */
      /*  With p^=axis2skew(p) */
      /*  */
      /*  See also: axis2skew, */
      /*  */
      /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
      /*  */
      /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
      /*   */
      /*  ST24R is free software: you can redistribute it and/or modify */
      /*  it under the terms of the GNU Lesser General Public License as published */
      /*  by the Free Software Foundation, either version 3 of the License, or */
      /*  (at your option) any later version. */
      /*   */
      /*  ST24R is distributed in the hope that it will be useful, */
      /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
      /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
      /*  GNU Lesser General Public License for more details. */
      /*   */
      /*  You should have received a copy of the GNU Leser General Public License */
      /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
      /*  */
      /*  http://www. */
      /*  */
      /*  CHANGES: */
      /*  Revision 1.1  2019/02/11 00:00:01 */
      /*  General cleanup of code: help comments, see also, copyright */
      /*  references, clarification of functions. */
      /*  */
      /*  	Ad = tform2adjoint(tform) */
      /*  */
      /*  "axis2skew" Generate a skew symmetric matrix from a vector (axis) . */
      /*  Use in SO(3). */
      /*  */
      /*  	r = axis2skew(w) */
      /*  */
      /*  Returns a skew symmetric matrix r 3x3 from the vector 3x1 w[a1;a2;a3;]. */
      /*     |0  -a3  a2|  */
      /*  r =|a3   0 -a1| */
      /*     |-a2 a1   0| */
      /*  */
      /*  See also: skew2axis. */
      /*  */
      /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
      /*  */
      /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
      /*   */
      /*  ST24R is free software: you can redistribute it and/or modify */
      /*  it under the terms of the GNU Lesser General Public License as published */
      /*  by the Free Software Foundation, either version 3 of the License, or */
      /*  (at your option) any later version. */
      /*   */
      /*  ST24R is distributed in the hope that it will be useful, */
      /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
      /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
      /*  GNU Lesser General Public License for more details. */
      /*   */
      /*  You should have received a copy of the GNU Leser General Public License */
      /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
      /*  */
      /*  http://www. */
      /*  */
      /*  CHANGES: */
      /*  Revision 1.1  2019/02/11 00:00:01 */
      /*  General cleanup of code: help comments, see also, copyright */
      /*  references, clarification of functions. */
      /*  */
      /*  r = axis2skew(w) */
      /*  */
      /*  */
      for (i6 = 0; i6 < 36; i6++) {
        Ad[i6] = iv0[i6];
      }

      dv2[0] = 0.0;
      dv2[3] = -PoE[14];
      dv2[6] = PoE[13];
      dv2[1] = PoE[14];
      dv2[4] = 0.0;
      dv2[7] = -PoE[12];
      dv2[2] = -PoE[13];
      dv2[5] = PoE[12];
      dv2[8] = 0.0;
      for (i6 = 0; i6 < 3; i6++) {
        for (PoE_tmp = 0; PoE_tmp < 3; PoE_tmp++) {
          i7 = PoE_tmp << 2;
          dv3[i6 + 3 * PoE_tmp] = (dv2[i6] * PoE[i7] + dv2[i6 + 3] * PoE[1 + i7])
            + dv2[i6 + 6] * PoE[2 + i7];
          c_PoE[PoE_tmp + 6 * i6] = PoE[PoE_tmp + (i6 << 2)];
        }
      }

      for (i6 = 0; i6 < 3; i6++) {
        k = 6 * (i6 + 3);
        c_PoE[k] = dv3[3 * i6];
        c_PoE[6 * i6 + 3] = 0.0;
        PoE_tmp = i6 << 2;
        c_PoE[k + 3] = PoE[PoE_tmp];
        c_PoE[1 + k] = dv3[1 + 3 * i6];
        c_PoE[6 * i6 + 4] = 0.0;
        c_PoE[k + 4] = PoE[1 + PoE_tmp];
        c_PoE[2 + k] = dv3[2 + 3 * i6];
        c_PoE[6 * i6 + 5] = 0.0;
        c_PoE[k + 5] = PoE[2 + PoE_tmp];
      }

      mldivide(c_PoE, Ad);
    }
  }

  /*  */
  /*  */
}

/*
 * File trailer for Aij2adjoint.c
 *
 * [EOF]
 */
