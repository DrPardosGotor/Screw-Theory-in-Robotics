/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: CCoriolisAij.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 10-Mar-2019 20:59:05
 */

#ifndef CCORIOLISAIJ_H
#define CCORIOLISAIJ_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "CCoriolisAij_types.h"

/* Function Declarations */
extern void CCoriolisAij(const double TwMag[49], const double LiMas[49], const
  double Thetap[7], double Ctdt[49]);

#endif

/*
 * File trailer for CCoriolisAij.h
 *
 * [EOF]
 */
