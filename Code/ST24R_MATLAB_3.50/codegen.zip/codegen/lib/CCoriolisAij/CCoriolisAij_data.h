/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: CCoriolisAij_data.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 10-Mar-2019 20:59:05
 */

#ifndef CCORIOLISAIJ_DATA_H
#define CCORIOLISAIJ_DATA_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "CCoriolisAij_types.h"

/* Variable Declarations */
extern const signed char iv0[36];

#endif

/*
 * File trailer for CCoriolisAij_data.h
 *
 * [EOF]
 */
