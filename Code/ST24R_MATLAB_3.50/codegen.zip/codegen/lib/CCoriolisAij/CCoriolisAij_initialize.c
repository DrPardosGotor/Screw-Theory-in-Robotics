/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: CCoriolisAij_initialize.c
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 10-Mar-2019 20:59:05
 */

/* Include Files */
#include "CCoriolisAij.h"
#include "CCoriolisAij_initialize.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void CCoriolisAij_initialize(void)
{
}

/*
 * File trailer for CCoriolisAij_initialize.c
 *
 * [EOF]
 */
