/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: CCoriolisAij_terminate.c
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 10-Mar-2019 20:59:05
 */

/* Include Files */
#include "CCoriolisAij.h"
#include "CCoriolisAij_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void CCoriolisAij_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for CCoriolisAij_terminate.c
 *
 * [EOF]
 */
