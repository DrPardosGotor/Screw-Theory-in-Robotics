/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: CCoriolisAij_terminate.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 10-Mar-2019 20:59:05
 */

#ifndef CCORIOLISAIJ_TERMINATE_H
#define CCORIOLISAIJ_TERMINATE_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "CCoriolisAij_types.h"

/* Function Declarations */
extern void CCoriolisAij_terminate(void);

#endif

/*
 * File trailer for CCoriolisAij_terminate.h
 *
 * [EOF]
 */
