/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: CCoriolisAij_types.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 10-Mar-2019 20:59:05
 */

#ifndef CCORIOLISAIJ_TYPES_H
#define CCORIOLISAIJ_TYPES_H

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for CCoriolisAij_types.h
 *
 * [EOF]
 */
