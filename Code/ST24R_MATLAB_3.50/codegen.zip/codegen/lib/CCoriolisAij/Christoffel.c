/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: Christoffel.c
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 10-Mar-2019 20:59:05
 */

/* Include Files */
#include <math.h>
#include "CCoriolisAij.h"
#include "Christoffel.h"
#include "Aij2adjoint.h"
#include "mldivide.h"
#include "CCoriolisAij_data.h"

/* Function Definitions */

/*
 * Arguments    : const double TwMag[49]
 *                const double LiMas[49]
 *                double i
 *                double j
 *                double k
 * Return Type  : double
 */
double Christoffel(const double TwMag[49], const double LiMas[49], double i,
                   double j, double k)
{
  double dMt;
  double m;
  int i1;
  int l;
  double b_l;
  double Hsli0[16];
  int Hsli0_tmp;
  double a[36];
  int i2;
  double d1;
  int a_tmp;
  double y[6];
  double E1[16];
  double b_a_tmp;
  double c_a_tmp;
  double E2[16];
  double E2_tmp;
  double b_E2_tmp;
  double b_E1[16];
  double b_E2[16];
  int c_E2_tmp;
  int d_E2_tmp;
  int i3;
  int i4;
  int i5;
  double b[36];
  double wr[9];
  double AdHsli0[36];
  double dv0[9];
  double b_b[36];
  double c_b[36];
  double b_AdHsli0[36];
  double d_b[36];
  static const signed char e_b[9] = { 1, 0, 0, 0, 1, 0, 0, 0, 1 };

  double tform[6];
  double c_AdHsli0[36];

  /*  "Christoffel" Christoffel Symbols for Coriolis matrix C(t,dt) */
  /*  for an open chain manipulator. */
  /*  computation based on the Adjoint Transformation Aij. */
  /*  Use in SE(3). */
  /*  */
  /*  	dMt = Christoffel(TwMag,LiMas,I,J,K) */
  /*  */
  /*  Gives the CHRISTOFFEL SYMBOLS (t,dt) for the Lagangian's equations:  */
  /*  M(t)*ddt + C(t,dt)*dt + N(t,dt) = T */
  /*  of the dynamics of the robot formed by links on an open chain.  */
  /*  */
  /*  INPUTS: */
  /*  TwMag = [Tw1; Mag1, ..., Twn; Magn] (7xn) */
  /*  for each rigid body joint (1..n). */
  /*  Tw1..Twn: The TWIST components for the joint movement. */
  /*  Mag1..Magn: The MAGNITUDE component for the joint SCREW movement. */
  /*  LiMas = [CM1; IT1; Mas1, ..., CMn; ITn; Masn] (7xn) */
  /*  for each rigid body link (1..n). */
  /*  CM1..CMn: Center of Mass x-y-z Position components to S for each Link. */
  /*  IT1..ITn: Inertia x-y-z components for each Link refered to its CM. */
  /*  Mas1..Masn: The Mass for each Link. */
  /*  I, J, K: index for Cristoffel formulation. */
  /*   */
  /*  dMt = dMij/dtk = Sum(l=max(i,j),n)[[Aki*Ei,Ek]'*Alk'*Ml*Alj*Ej + Ei'*Ali'*Ml*Alk*[Akj*Ej,Ek]] */
  /*   */
  /*  With Ml being the link inertia nxn LinkInertiaS.  */
  /*  With Ei being the twist xi 6x1. */
  /*  With Aij being an element 6x6 of the adjoint transformation Aij2adjoint */
  /*  */
  /*  See also: LinkInertiaS, Aij2adjoint,. CCoriolisAij. */
  /*  */
  /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
  /*  */
  /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
  /*   */
  /*  ST24R is free software: you can redistribute it and/or modify */
  /*  it under the terms of the GNU Lesser General Public License as published */
  /*  by the Free Software Foundation, either version 3 of the License, or */
  /*  (at your option) any later version. */
  /*   */
  /*  ST24R is distributed in the hope that it will be useful, */
  /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
  /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
  /*  GNU Lesser General Public License for more details. */
  /*   */
  /*  You should have received a copy of the GNU Leser General Public License */
  /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
  /*  */
  /*  http://www. */
  /*  */
  /*  CHANGES: */
  /*  Revision 1.1  2019/02/11 00:00:01 */
  /*  General cleanup of code: help comments, see also, copyright */
  /*  references, clarification of functions. */
  /*  */
  /*  dMt = Christoffel(TwMag,LiMas,I,J,K) */
  /*  */
  m = fmax(i, j);
  dMt = 0.0;
  i1 = (int)(7.0 + (1.0 - m));
  for (l = 0; l < i1; l++) {
    b_l = m + (double)l;

    /*  */
    /*  TRVP2TFORM Convert to Homogeneous matrix a translation P vector  */
    /*   Hp = TRVP2TFORM(P) converts a translation P axis into the */
    /*   corresponding homogeneous matrix H. P is a position in longitude units. */
    /*  */
    /*    Example: */
    /*        %Calculate the homogeneous matrix for a translation p = [px;py;pz] */
    /*        on X axis. */
    /*        Hxp = trvP2tform(p) */
    /*        % Hp = [1 0 0 px; 0 1 0 py; 0 0 1 pz; 0 0 0 1]  */
    /*        ans = */
    /*                 1         0         0         px */
    /*                 0         1         0         py */
    /*                 0         0         1         pz */
    /*                 0         0         0         1 */
    /*  */
    /*  See also trvY2tform(p), trvY2tform(p), trvZ2tform(p). */
    /*  */
    /*  Copyright (C) 2003-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  Hxp = trvX2tform(pg) */
    /*  */
    Hsli0[0] = 1.0;
    Hsli0[4] = 0.0;
    Hsli0[8] = 0.0;
    Hsli0_tmp = 7 * ((int)b_l - 1);
    Hsli0[12] = LiMas[Hsli0_tmp];
    Hsli0[1] = 0.0;
    Hsli0[5] = 1.0;
    Hsli0[9] = 0.0;
    Hsli0[13] = LiMas[1 + Hsli0_tmp];
    Hsli0[2] = 0.0;
    Hsli0[6] = 0.0;
    Hsli0[10] = 1.0;
    Hsli0[14] = LiMas[2 + Hsli0_tmp];
    Hsli0[3] = 0.0;
    Hsli0[7] = 0.0;
    Hsli0[11] = 0.0;
    Hsli0[15] = 1.0;

    /*  */
    Aij2adjoint(k, i, TwMag, a);
    for (i2 = 0; i2 < 6; i2++) {
      d1 = 0.0;
      for (a_tmp = 0; a_tmp < 6; a_tmp++) {
        d1 += a[i2 + 6 * a_tmp] * TwMag[a_tmp + 7 * ((int)i - 1)];
      }

      y[i2] = d1;
    }

    /*  */
    /*  "twistbracket" Computes the bracket operation to two twists. */
    /*  Use in SE(3). */
    /*  */
    /*  	xi = twistbracket(x1,x2) */
    /*  */
    /*  Returns a twist "xi" from a the application of the bracket operation to */
    /*  the twists x1 and x2. This operation is a generalization of the cross */
    /*  product on R3 to vectors in R6. */
    /*     |v|                              v  */
    /*  xi=| |  = [E1,E2] = [E1^*E2^-E2^*E1^]  */
    /*     |W|          */
    /*  Con ^ wedge or twist2tform operation. */
    /*  Con v vee or tform2twist operation. */
    /*  */
    /*  See also: tform2twist, twist2tform. */
    /*  */
    /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  x = twistbracket(x1,x2) */
    /*  */
    /*  "TWIST2TFORM" Convert a twist "xi" (6x1) to homogeneous matrix "E^" 3x4. */
    /*  Use in SE(3). */
    /*  */
    /*  	tform = twist2tform(xi) */
    /*  */
    /*  Returns the homogeneous "h" matrix 4x4 from a twixt "xi". */
    /*     |v|         |W^ v| */
    /*  xi=| |  =>  E^=|    |  andn W^ = skew(W) */
    /*     |W|         |0  0| */
    /*  */
    /*  */
    /*  See also: tform2twist, axis2skew. */
    /*  */
    /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  	tform = twist2tform(xi) */
    /*  */
    /*  "axis2skew" Generate a skew symmetric matrix from a vector (axis) . */
    /*  Use in SO(3). */
    /*  */
    /*  	r = axis2skew(w) */
    /*  */
    /*  Returns a skew symmetric matrix r 3x3 from the vector 3x1 w[a1;a2;a3;]. */
    /*     |0  -a3  a2|  */
    /*  r =|a3   0 -a1| */
    /*     |-a2 a1   0| */
    /*  */
    /*  See also: skew2axis. */
    /*  */
    /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  r = axis2skew(w) */
    /*  */
    E1[0] = 0.0;
    E1[4] = -y[5];
    E1[8] = y[4];
    E1[12] = y[0];
    E1[1] = y[5];
    E1[5] = 0.0;
    E1[9] = -y[3];
    E1[13] = y[1];
    E1[2] = -y[4];
    E1[6] = y[3];
    E1[10] = 0.0;
    E1[14] = y[2];

    /*  */
    /*  */
    /*  "TWIST2TFORM" Convert a twist "xi" (6x1) to homogeneous matrix "E^" 3x4. */
    /*  Use in SE(3). */
    /*  */
    /*  	tform = twist2tform(xi) */
    /*  */
    /*  Returns the homogeneous "h" matrix 4x4 from a twixt "xi". */
    /*     |v|         |W^ v| */
    /*  xi=| |  =>  E^=|    |  andn W^ = skew(W) */
    /*     |W|         |0  0| */
    /*  */
    /*  */
    /*  See also: tform2twist, axis2skew. */
    /*  */
    /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  	tform = twist2tform(xi) */
    i2 = 7 * ((int)k - 1);
    d1 = TwMag[3 + i2];
    b_a_tmp = TwMag[4 + i2];
    c_a_tmp = TwMag[5 + i2];

    /*  */
    /*  "axis2skew" Generate a skew symmetric matrix from a vector (axis) . */
    /*  Use in SO(3). */
    /*  */
    /*  	r = axis2skew(w) */
    /*  */
    /*  Returns a skew symmetric matrix r 3x3 from the vector 3x1 w[a1;a2;a3;]. */
    /*     |0  -a3  a2|  */
    /*  r =|a3   0 -a1| */
    /*     |-a2 a1   0| */
    /*  */
    /*  See also: skew2axis. */
    /*  */
    /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  r = axis2skew(w) */
    /*  */
    E2[0] = 0.0;
    E2[4] = -c_a_tmp;
    E2[8] = b_a_tmp;
    E2[12] = TwMag[i2];
    E2[1] = c_a_tmp;
    E2[5] = 0.0;
    E2[9] = -d1;
    E2_tmp = TwMag[1 + i2];
    E2[13] = E2_tmp;
    E2[2] = -b_a_tmp;
    E2[6] = d1;
    E2[10] = 0.0;
    b_E2_tmp = TwMag[2 + i2];
    E2[14] = b_E2_tmp;
    E1[3] = 0.0;
    E2[3] = 0.0;
    E1[7] = 0.0;
    E2[7] = 0.0;
    E1[11] = 0.0;
    E2[11] = 0.0;
    E1[15] = 0.0;
    E2[15] = 0.0;

    /*  */
    for (i2 = 0; i2 < 4; i2++) {
      for (a_tmp = 0; a_tmp < 4; a_tmp++) {
        c_E2_tmp = a_tmp << 2;
        d_E2_tmp = i2 + c_E2_tmp;
        b_E2[d_E2_tmp] = 0.0;
        i3 = 1 + c_E2_tmp;
        i4 = 2 + c_E2_tmp;
        i5 = 3 + c_E2_tmp;
        b_E2[d_E2_tmp] = ((E2[i2] * E1[c_E2_tmp] + E2[i2 + 4] * E1[i3]) + E2[i2
                          + 8] * E1[i4]) + E2[i2 + 12] * E1[i5];
        b_E1[d_E2_tmp] = ((E1[i2] * E2[c_E2_tmp] + E1[i2 + 4] * E2[i3]) + E1[i2
                          + 8] * E2[i4]) + E1[i2 + 12] * E2[i5];
      }
    }

    for (i2 = 0; i2 < 16; i2++) {
      b_E1[i2] -= b_E2[i2];
    }

    /*  */
    /*  "TFORM2TWIST" Convert a matrix "E^" 4x4 into a twist "xi" 6x1. */
    /*  Use in SE(3). */
    /*  */
    /*  	xi = tform2twist(tform) */
    /*  */
    /*  Returns a twixt "xi" from a homogeneous "tform" matrix 4x4. */
    /*     |v|         |W^ v| */
    /*  xi=| |  <=  E^=|    |  */
    /*     |W|         |0  0| */
    /*  */
    /*  */
    /*  See also: twist2tform, skew2axis. */
    /*  */
    /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  	xi = tform2twist(tform) */
    /*  */
    /*  "skew2axis" Generate an axis from an skew symmetric matrix. */
    /*  Use in SO(3). */
    /*  */
    /*  	w = skew2axis(r) */
    /*  */
    /*  Returns a vector 3x1 w[a1;a2;a3;] from a skew symmetric matrix r 3x3 . */
    /*     |0  -a3  a2|  */
    /*  r =|a3   0 -a1| */
    /*     |-a2 a1   0| */
    /*  */
    /*  See also: axis2skew. */
    /*  */
    /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  w = skew2axis(r) */
    /*  */
    /*  */
    /*  */
    Aij2adjoint(b_l, k, TwMag, a);
    for (i2 = 0; i2 < 6; i2++) {
      for (a_tmp = 0; a_tmp < 6; a_tmp++) {
        b[a_tmp + 6 * i2] = a[i2 + 6 * a_tmp];
      }
    }

    /*  */
    /*  "linkInertiaS" the LINK TRANSFORMED INERTIA MATRIX for robot's link. */
    /*  Use in SE(3). */
    /*  */
    /*  	ImS = LinkInertiaS(Hsli0,Ii,mi) */
    /*  */
    /*  It gives the LINK TRANSFORMED INERTIA MATRIX corresponding to the inertia */
    /*  of the link into the base frame of the manipulator. */
    /*  */
    /*  INPUTS: */
    /*  Hsli0 is the homogeneous matrix 4x4 for the pose of the i link frame "L",  */
    /*  associated to the Center o Mass, at the reference (home) configuration  */
    /*  of the manipulator. */
    /*  Ii: Inertia Tensor (3x1) = [Ixi; Iyi; Izi] are the moments of  */
    /*  inertia about the x, y, and z-axes of the ith link frame on the CM. */
    /*  mi: link mass. */
    /*  */
    /*  the Inertia matrix "ImS" is nxn with n the number of links (joints). */
    /*  (Ad(Hsl0)^-1)*          */
    /*  AdHsl0 = Ad(Hsl0^-1)= Adjoint transformation of the inverse of the  */
    /*  center of mass ref config. */
    /*                       |mI  0| */
    /*  ImS = (Ad(Hsl0)^-1)'*|     |*(Ad(Hsl0)^-1)=(Ad(Hsl0)^-1)'*M*(Ad(Hsl0)^-1) */
    /*                       |0  Ii| */
    /*  ImS = Link Transformed Inertia Matrix. */
    /*  with M Generalized Inertia Matrix, defined through the diagonal mass and */
    /*  the inertia tensor. */
    /*  */
    /*  See also: tform2adjoint. */
    /*  */
    /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  ImS = LinkInertiaS(Hsli0,Ii,mi) */
    /*  */
    /*  */
    /*  "TFORM2ADJOINT" Find the adjoint matrix associated with a tform. */
    /*  Use in SE(3). */
    /*  */
    /*  	Ad = tform2adjoint(tform) */
    /*  */
    /*  ADJOINT TRANSFORMATION: */
    /*  it is used to transforms twist from one coordinate frame to another. */
    /*  Vs =Adg*Vb ; Vac = Adgab*Vbc ; E'=Adg*E */
    /*  The adjoint transformation maps twist vectors to twist vectors. */
    /*  Compute the Adg in R^6 (6x6 matrix9 from the homogeneous matrix g 4x4. */
    /*       |R p^R|            |R p| */
    /*  Adg =|     | <= tform = |   | */
    /*       |0   R|            |0 1| */
    /*  With p^=axis2skew(p) */
    /*  */
    /*  See also: axis2skew, */
    /*  */
    /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  	Ad = tform2adjoint(tform) */
    /*  */
    /*  "axis2skew" Generate a skew symmetric matrix from a vector (axis) . */
    /*  Use in SO(3). */
    /*  */
    /*  	r = axis2skew(w) */
    /*  */
    /*  Returns a skew symmetric matrix r 3x3 from the vector 3x1 w[a1;a2;a3;]. */
    /*     |0  -a3  a2|  */
    /*  r =|a3   0 -a1| */
    /*     |-a2 a1   0| */
    /*  */
    /*  See also: skew2axis. */
    /*  */
    /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  r = axis2skew(w) */
    /*  */
    /*  */
    for (i2 = 0; i2 < 36; i2++) {
      AdHsli0[i2] = iv0[i2];
    }

    wr[0] = 0.0;
    wr[3] = -LiMas[2 + Hsli0_tmp];
    wr[6] = LiMas[1 + Hsli0_tmp];
    wr[1] = LiMas[2 + Hsli0_tmp];
    wr[4] = 0.0;
    wr[7] = -LiMas[Hsli0_tmp];
    wr[2] = -LiMas[1 + Hsli0_tmp];
    wr[5] = LiMas[Hsli0_tmp];
    wr[8] = 0.0;
    for (i2 = 0; i2 < 3; i2++) {
      for (a_tmp = 0; a_tmp < 3; a_tmp++) {
        i3 = a_tmp << 2;
        dv0[i2 + 3 * a_tmp] = (wr[i2] * Hsli0[i3] + wr[i2 + 3] * Hsli0[1 + i3])
          + wr[i2 + 6] * Hsli0[2 + i3];
        a[a_tmp + 6 * i2] = Hsli0[a_tmp + (i2 << 2)];
      }
    }

    for (i2 = 0; i2 < 3; i2++) {
      a_tmp = 6 * (i2 + 3);
      a[a_tmp] = dv0[3 * i2];
      a[6 * i2 + 3] = 0.0;
      c_E2_tmp = i2 << 2;
      a[a_tmp + 3] = Hsli0[c_E2_tmp];
      a[1 + a_tmp] = dv0[1 + 3 * i2];
      a[6 * i2 + 4] = 0.0;
      a[a_tmp + 4] = Hsli0[1 + c_E2_tmp];
      a[2 + a_tmp] = dv0[2 + 3 * i2];
      a[6 * i2 + 5] = 0.0;
      a[a_tmp + 5] = Hsli0[2 + c_E2_tmp];
    }

    mldivide(a, AdHsli0);

    /*  Ad(Hsli0)^-1 */
    /*     */
    Aij2adjoint(b_l, j, TwMag, b_b);
    Aij2adjoint(b_l, i, TwMag, a);
    for (i2 = 0; i2 < 6; i2++) {
      for (a_tmp = 0; a_tmp < 6; a_tmp++) {
        c_b[a_tmp + 6 * i2] = a[i2 + 6 * a_tmp];
      }
    }

    /*  */
    /*  "linkInertiaS" the LINK TRANSFORMED INERTIA MATRIX for robot's link. */
    /*  Use in SE(3). */
    /*  */
    /*  	ImS = LinkInertiaS(Hsli0,Ii,mi) */
    /*  */
    /*  It gives the LINK TRANSFORMED INERTIA MATRIX corresponding to the inertia */
    /*  of the link into the base frame of the manipulator. */
    /*  */
    /*  INPUTS: */
    /*  Hsli0 is the homogeneous matrix 4x4 for the pose of the i link frame "L",  */
    /*  associated to the Center o Mass, at the reference (home) configuration  */
    /*  of the manipulator. */
    /*  Ii: Inertia Tensor (3x1) = [Ixi; Iyi; Izi] are the moments of  */
    /*  inertia about the x, y, and z-axes of the ith link frame on the CM. */
    /*  mi: link mass. */
    /*  */
    /*  the Inertia matrix "ImS" is nxn with n the number of links (joints). */
    /*  (Ad(Hsl0)^-1)*          */
    /*  AdHsl0 = Ad(Hsl0^-1)= Adjoint transformation of the inverse of the  */
    /*  center of mass ref config. */
    /*                       |mI  0| */
    /*  ImS = (Ad(Hsl0)^-1)'*|     |*(Ad(Hsl0)^-1)=(Ad(Hsl0)^-1)'*M*(Ad(Hsl0)^-1) */
    /*                       |0  Ii| */
    /*  ImS = Link Transformed Inertia Matrix. */
    /*  with M Generalized Inertia Matrix, defined through the diagonal mass and */
    /*  the inertia tensor. */
    /*  */
    /*  See also: tform2adjoint. */
    /*  */
    /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  ImS = LinkInertiaS(Hsli0,Ii,mi) */
    /*  */
    /*  */
    /*  "TFORM2ADJOINT" Find the adjoint matrix associated with a tform. */
    /*  Use in SE(3). */
    /*  */
    /*  	Ad = tform2adjoint(tform) */
    /*  */
    /*  ADJOINT TRANSFORMATION: */
    /*  it is used to transforms twist from one coordinate frame to another. */
    /*  Vs =Adg*Vb ; Vac = Adgab*Vbc ; E'=Adg*E */
    /*  The adjoint transformation maps twist vectors to twist vectors. */
    /*  Compute the Adg in R^6 (6x6 matrix9 from the homogeneous matrix g 4x4. */
    /*       |R p^R|            |R p| */
    /*  Adg =|     | <= tform = |   | */
    /*       |0   R|            |0 1| */
    /*  With p^=axis2skew(p) */
    /*  */
    /*  See also: axis2skew, */
    /*  */
    /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  	Ad = tform2adjoint(tform) */
    /*  */
    /*  "axis2skew" Generate a skew symmetric matrix from a vector (axis) . */
    /*  Use in SO(3). */
    /*  */
    /*  	r = axis2skew(w) */
    /*  */
    /*  Returns a skew symmetric matrix r 3x3 from the vector 3x1 w[a1;a2;a3;]. */
    /*     |0  -a3  a2|  */
    /*  r =|a3   0 -a1| */
    /*     |-a2 a1   0| */
    /*  */
    /*  See also: skew2axis. */
    /*  */
    /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  r = axis2skew(w) */
    /*  */
    /*  */
    for (i2 = 0; i2 < 36; i2++) {
      b_AdHsli0[i2] = iv0[i2];
    }

    wr[0] = 0.0;
    wr[3] = -LiMas[2 + Hsli0_tmp];
    wr[6] = LiMas[1 + Hsli0_tmp];
    wr[1] = LiMas[2 + Hsli0_tmp];
    wr[4] = 0.0;
    wr[7] = -LiMas[Hsli0_tmp];
    wr[2] = -LiMas[1 + Hsli0_tmp];
    wr[5] = LiMas[Hsli0_tmp];
    wr[8] = 0.0;
    for (i2 = 0; i2 < 3; i2++) {
      for (a_tmp = 0; a_tmp < 3; a_tmp++) {
        i3 = a_tmp << 2;
        dv0[i2 + 3 * a_tmp] = (wr[i2] * Hsli0[i3] + wr[i2 + 3] * Hsli0[1 + i3])
          + wr[i2 + 6] * Hsli0[2 + i3];
        a[a_tmp + 6 * i2] = Hsli0[a_tmp + (i2 << 2)];
      }
    }

    for (i2 = 0; i2 < 3; i2++) {
      a_tmp = 6 * (i2 + 3);
      a[a_tmp] = dv0[3 * i2];
      a[6 * i2 + 3] = 0.0;
      c_E2_tmp = i2 << 2;
      a[a_tmp + 3] = Hsli0[c_E2_tmp];
      a[1 + a_tmp] = dv0[1 + 3 * i2];
      a[6 * i2 + 4] = 0.0;
      a[a_tmp + 4] = Hsli0[1 + c_E2_tmp];
      a[2 + a_tmp] = dv0[2 + 3 * i2];
      a[6 * i2 + 5] = 0.0;
      a[a_tmp + 5] = Hsli0[2 + c_E2_tmp];
    }

    mldivide(a, b_AdHsli0);

    /*  Ad(Hsli0)^-1 */
    /*     */
    Aij2adjoint(b_l, k, TwMag, d_b);
    Aij2adjoint(k, j, TwMag, a);
    for (i2 = 0; i2 < 6; i2++) {
      b_l = 0.0;
      for (a_tmp = 0; a_tmp < 6; a_tmp++) {
        b_l += a[i2 + 6 * a_tmp] * TwMag[a_tmp + 7 * ((int)j - 1)];
      }

      y[i2] = b_l;
    }

    /*  */
    /*  "twistbracket" Computes the bracket operation to two twists. */
    /*  Use in SE(3). */
    /*  */
    /*  	xi = twistbracket(x1,x2) */
    /*  */
    /*  Returns a twist "xi" from a the application of the bracket operation to */
    /*  the twists x1 and x2. This operation is a generalization of the cross */
    /*  product on R3 to vectors in R6. */
    /*     |v|                              v  */
    /*  xi=| |  = [E1,E2] = [E1^*E2^-E2^*E1^]  */
    /*     |W|          */
    /*  Con ^ wedge or twist2tform operation. */
    /*  Con v vee or tform2twist operation. */
    /*  */
    /*  See also: tform2twist, twist2tform. */
    /*  */
    /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  x = twistbracket(x1,x2) */
    /*  */
    /*  "TWIST2TFORM" Convert a twist "xi" (6x1) to homogeneous matrix "E^" 3x4. */
    /*  Use in SE(3). */
    /*  */
    /*  	tform = twist2tform(xi) */
    /*  */
    /*  Returns the homogeneous "h" matrix 4x4 from a twixt "xi". */
    /*     |v|         |W^ v| */
    /*  xi=| |  =>  E^=|    |  andn W^ = skew(W) */
    /*     |W|         |0  0| */
    /*  */
    /*  */
    /*  See also: tform2twist, axis2skew. */
    /*  */
    /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  	tform = twist2tform(xi) */
    /*  */
    /*  "axis2skew" Generate a skew symmetric matrix from a vector (axis) . */
    /*  Use in SO(3). */
    /*  */
    /*  	r = axis2skew(w) */
    /*  */
    /*  Returns a skew symmetric matrix r 3x3 from the vector 3x1 w[a1;a2;a3;]. */
    /*     |0  -a3  a2|  */
    /*  r =|a3   0 -a1| */
    /*     |-a2 a1   0| */
    /*  */
    /*  See also: skew2axis. */
    /*  */
    /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  r = axis2skew(w) */
    /*  */
    E1[0] = 0.0;
    E1[4] = -y[5];
    E1[8] = y[4];
    E1[12] = y[0];
    E1[1] = y[5];
    E1[5] = 0.0;
    E1[9] = -y[3];
    E1[13] = y[1];
    E1[2] = -y[4];
    E1[6] = y[3];
    E1[10] = 0.0;
    E1[14] = y[2];

    /*  */
    /*  */
    /*  "TWIST2TFORM" Convert a twist "xi" (6x1) to homogeneous matrix "E^" 3x4. */
    /*  Use in SE(3). */
    /*  */
    /*  	tform = twist2tform(xi) */
    /*  */
    /*  Returns the homogeneous "h" matrix 4x4 from a twixt "xi". */
    /*     |v|         |W^ v| */
    /*  xi=| |  =>  E^=|    |  andn W^ = skew(W) */
    /*     |W|         |0  0| */
    /*  */
    /*  */
    /*  See also: tform2twist, axis2skew. */
    /*  */
    /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  	tform = twist2tform(xi) */
    /*  */
    /*  "axis2skew" Generate a skew symmetric matrix from a vector (axis) . */
    /*  Use in SO(3). */
    /*  */
    /*  	r = axis2skew(w) */
    /*  */
    /*  Returns a skew symmetric matrix r 3x3 from the vector 3x1 w[a1;a2;a3;]. */
    /*     |0  -a3  a2|  */
    /*  r =|a3   0 -a1| */
    /*     |-a2 a1   0| */
    /*  */
    /*  See also: skew2axis. */
    /*  */
    /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  r = axis2skew(w) */
    /*  */
    E2[0] = 0.0;
    E2[4] = -c_a_tmp;
    E2[8] = b_a_tmp;
    E2[12] = TwMag[7 * ((int)k - 1)];
    E2[1] = c_a_tmp;
    E2[5] = 0.0;
    E2[9] = -d1;
    E2[13] = E2_tmp;
    E2[2] = -b_a_tmp;
    E2[6] = d1;
    E2[10] = 0.0;
    E2[14] = b_E2_tmp;
    E1[3] = 0.0;
    E2[3] = 0.0;
    E1[7] = 0.0;
    E2[7] = 0.0;
    E1[11] = 0.0;
    E2[11] = 0.0;
    E1[15] = 0.0;
    E2[15] = 0.0;

    /*  */
    for (i2 = 0; i2 < 4; i2++) {
      for (a_tmp = 0; a_tmp < 4; a_tmp++) {
        c_E2_tmp = a_tmp << 2;
        d_E2_tmp = i2 + c_E2_tmp;
        b_E2[d_E2_tmp] = 0.0;
        i3 = 1 + c_E2_tmp;
        i4 = 2 + c_E2_tmp;
        i5 = 3 + c_E2_tmp;
        b_E2[d_E2_tmp] = ((E2[i2] * E1[c_E2_tmp] + E2[i2 + 4] * E1[i3]) + E2[i2
                          + 8] * E1[i4]) + E2[i2 + 12] * E1[i5];
        Hsli0[d_E2_tmp] = ((E1[i2] * E2[c_E2_tmp] + E1[i2 + 4] * E2[i3]) + E1[i2
                           + 8] * E2[i4]) + E1[i2 + 12] * E2[i5];
      }
    }

    for (i2 = 0; i2 < 16; i2++) {
      Hsli0[i2] -= b_E2[i2];
    }

    /*  */
    /*  "TFORM2TWIST" Convert a matrix "E^" 4x4 into a twist "xi" 6x1. */
    /*  Use in SE(3). */
    /*  */
    /*  	xi = tform2twist(tform) */
    /*  */
    /*  Returns a twixt "xi" from a homogeneous "tform" matrix 4x4. */
    /*     |v|         |W^ v| */
    /*  xi=| |  <=  E^=|    |  */
    /*     |W|         |0  0| */
    /*  */
    /*  */
    /*  See also: twist2tform, skew2axis. */
    /*  */
    /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  	xi = tform2twist(tform) */
    /*  */
    /*  "skew2axis" Generate an axis from an skew symmetric matrix. */
    /*  Use in SO(3). */
    /*  */
    /*  	w = skew2axis(r) */
    /*  */
    /*  Returns a vector 3x1 w[a1;a2;a3;] from a skew symmetric matrix r 3x3 . */
    /*     |0  -a3  a2|  */
    /*  r =|a3   0 -a1| */
    /*     |-a2 a1   0| */
    /*  */
    /*  See also: axis2skew. */
    /*  */
    /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  w = skew2axis(r) */
    /*  */
    /*  */
    /*  */
    y[0] = b_E1[12];
    y[1] = b_E1[13];
    y[2] = b_E1[14];
    y[3] = b_E1[6];
    y[4] = b_E1[8];
    y[5] = b_E1[1];
    b_l = LiMas[6 + Hsli0_tmp];
    for (i2 = 0; i2 < 3; i2++) {
      a[6 * i2] = b_l * (double)e_b[3 * i2];
      a_tmp = 6 * (i2 + 3);
      a[a_tmp] = 0.0;
      a[6 * i2 + 3] = 0.0;
      a[1 + 6 * i2] = b_l * (double)e_b[1 + 3 * i2];
      a[1 + a_tmp] = 0.0;
      a[6 * i2 + 4] = 0.0;
      a[2 + 6 * i2] = b_l * (double)e_b[2 + 3 * i2];
      a[2 + a_tmp] = 0.0;
      a[6 * i2 + 5] = 0.0;
    }

    b_a_tmp = LiMas[3 + Hsli0_tmp];
    a[21] = b_a_tmp;
    a[27] = 0.0;
    a[33] = 0.0;
    a[22] = 0.0;
    c_a_tmp = LiMas[4 + Hsli0_tmp];
    a[28] = c_a_tmp;
    a[34] = 0.0;
    a[23] = 0.0;
    a[29] = 0.0;
    E2_tmp = LiMas[5 + Hsli0_tmp];
    a[35] = E2_tmp;
    for (i2 = 0; i2 < 6; i2++) {
      tform[i2] = 0.0;
      for (a_tmp = 0; a_tmp < 6; a_tmp++) {
        d1 = 0.0;
        for (i3 = 0; i3 < 6; i3++) {
          d1 += AdHsli0[i3 + 6 * i2] * a[i3 + 6 * a_tmp];
        }

        c_AdHsli0[i2 + 6 * a_tmp] = d1;
        tform[i2] += y[a_tmp] * b[a_tmp + 6 * i2];
      }
    }

    for (i2 = 0; i2 < 6; i2++) {
      for (a_tmp = 0; a_tmp < 6; a_tmp++) {
        d1 = 0.0;
        for (i3 = 0; i3 < 6; i3++) {
          d1 += c_AdHsli0[i2 + 6 * i3] * AdHsli0[i3 + 6 * a_tmp];
        }

        a[i2 + 6 * a_tmp] = d1;
      }
    }

    for (i2 = 0; i2 < 6; i2++) {
      d1 = 0.0;
      for (a_tmp = 0; a_tmp < 6; a_tmp++) {
        d1 += tform[a_tmp] * a[a_tmp + 6 * i2];
      }

      y[i2] = d1;
    }

    b_E2_tmp = 0.0;
    for (i2 = 0; i2 < 6; i2++) {
      d1 = 0.0;
      for (a_tmp = 0; a_tmp < 6; a_tmp++) {
        d1 += y[a_tmp] * b_b[a_tmp + 6 * i2];
      }

      b_E2_tmp += d1 * TwMag[i2 + 7 * ((int)j - 1)];
    }

    for (i2 = 0; i2 < 3; i2++) {
      a[6 * i2] = b_l * (double)e_b[3 * i2];
      a_tmp = 6 * (i2 + 3);
      a[a_tmp] = 0.0;
      a[6 * i2 + 3] = 0.0;
      a[1 + 6 * i2] = b_l * (double)e_b[1 + 3 * i2];
      a[1 + a_tmp] = 0.0;
      a[6 * i2 + 4] = 0.0;
      a[2 + 6 * i2] = b_l * (double)e_b[2 + 3 * i2];
      a[2 + a_tmp] = 0.0;
      a[6 * i2 + 5] = 0.0;
    }

    a[21] = b_a_tmp;
    a[27] = 0.0;
    a[33] = 0.0;
    a[22] = 0.0;
    a[28] = c_a_tmp;
    a[34] = 0.0;
    a[23] = 0.0;
    a[29] = 0.0;
    a[35] = E2_tmp;
    for (i2 = 0; i2 < 6; i2++) {
      y[i2] = 0.0;
      for (a_tmp = 0; a_tmp < 6; a_tmp++) {
        d1 = 0.0;
        for (i3 = 0; i3 < 6; i3++) {
          d1 += b_AdHsli0[i3 + 6 * i2] * a[i3 + 6 * a_tmp];
        }

        AdHsli0[i2 + 6 * a_tmp] = d1;
        y[i2] += TwMag[a_tmp + 7 * ((int)i - 1)] * c_b[a_tmp + 6 * i2];
      }

      for (a_tmp = 0; a_tmp < 6; a_tmp++) {
        d1 = 0.0;
        for (i3 = 0; i3 < 6; i3++) {
          d1 += AdHsli0[i2 + 6 * i3] * b_AdHsli0[i3 + 6 * a_tmp];
        }

        c_AdHsli0[i2 + 6 * a_tmp] = d1;
      }
    }

    for (i2 = 0; i2 < 6; i2++) {
      d1 = 0.0;
      for (a_tmp = 0; a_tmp < 6; a_tmp++) {
        d1 += y[a_tmp] * c_AdHsli0[a_tmp + 6 * i2];
      }

      tform[i2] = d1;
    }

    y[0] = Hsli0[12];
    y[1] = Hsli0[13];
    y[2] = Hsli0[14];
    y[3] = Hsli0[6];
    y[4] = Hsli0[8];
    y[5] = Hsli0[1];
    b_l = 0.0;
    for (i2 = 0; i2 < 6; i2++) {
      d1 = 0.0;
      for (a_tmp = 0; a_tmp < 6; a_tmp++) {
        d1 += tform[a_tmp] * d_b[a_tmp + 6 * i2];
      }

      b_l += d1 * y[i2];
    }

    dMt = (dMt + b_E2_tmp) + b_l;
  }

  /*  */
  return dMt;
}

/*
 * File trailer for Christoffel.c
 *
 * [EOF]
 */
