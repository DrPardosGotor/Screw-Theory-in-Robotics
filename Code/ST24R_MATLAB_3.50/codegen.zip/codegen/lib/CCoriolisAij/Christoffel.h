/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: Christoffel.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 10-Mar-2019 20:59:05
 */

#ifndef CHRISTOFFEL_H
#define CHRISTOFFEL_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "CCoriolisAij_types.h"

/* Function Declarations */
extern double Christoffel(const double TwMag[49], const double LiMas[49], double
  i, double j, double k);

#endif

/*
 * File trailer for Christoffel.h
 *
 * [EOF]
 */
