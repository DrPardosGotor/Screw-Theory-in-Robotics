/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: _coder_CCoriolisAij_api.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 10-Mar-2019 20:59:05
 */

#ifndef _CODER_CCORIOLISAIJ_API_H
#define _CODER_CCORIOLISAIJ_API_H

/* Include Files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include <stddef.h>
#include <stdlib.h>
#include "_coder_CCoriolisAij_api.h"

/* Variable Declarations */
extern emlrtCTX emlrtRootTLSGlobal;
extern emlrtContext emlrtContextGlobal;

/* Function Declarations */
extern void CCoriolisAij(real_T TwMag[49], real_T LiMas[49], real_T Thetap[7],
  real_T Ctdt[49]);
extern void CCoriolisAij_api(const mxArray * const prhs[3], int32_T nlhs, const
  mxArray *plhs[1]);
extern void CCoriolisAij_atexit(void);
extern void CCoriolisAij_initialize(void);
extern void CCoriolisAij_terminate(void);
extern void CCoriolisAij_xil_shutdown(void);
extern void CCoriolisAij_xil_terminate(void);

#endif

/*
 * File trailer for _coder_CCoriolisAij_api.h
 *
 * [EOF]
 */
