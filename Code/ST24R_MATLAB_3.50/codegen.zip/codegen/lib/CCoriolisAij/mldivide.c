/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: mldivide.c
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 10-Mar-2019 20:59:05
 */

/* Include Files */
#include <math.h>
#include <string.h>
#include "CCoriolisAij.h"
#include "mldivide.h"

/* Function Definitions */

/*
 * Arguments    : const double A[36]
 *                double B[36]
 * Return Type  : void
 */
void mldivide(const double A[36], double B[36])
{
  double b_A[36];
  int i10;
  int j;
  signed char ipiv[6];
  int b;
  int jj;
  int iy;
  int jp1j;
  int k;
  int n;
  int jA;
  int ix;
  double smax;
  int i11;
  double s;
  memcpy(&b_A[0], &A[0], 36U * sizeof(double));
  for (i10 = 0; i10 < 6; i10++) {
    ipiv[i10] = (signed char)(1 + i10);
  }

  for (j = 0; j < 5; j++) {
    b = j * 7;
    jj = j * 7;
    jp1j = b + 2;
    n = 6 - j;
    jA = 0;
    ix = b;
    smax = fabs(b_A[b]);
    for (k = 2; k <= n; k++) {
      ix++;
      s = fabs(b_A[ix]);
      if (s > smax) {
        jA = k - 1;
        smax = s;
      }
    }

    if (b_A[jj + jA] != 0.0) {
      if (jA != 0) {
        iy = j + jA;
        ipiv[j] = (signed char)(iy + 1);
        ix = j;
        for (k = 0; k < 6; k++) {
          smax = b_A[ix];
          b_A[ix] = b_A[iy];
          b_A[iy] = smax;
          ix += 6;
          iy += 6;
        }
      }

      i10 = (jj - j) + 6;
      for (n = jp1j; n <= i10; n++) {
        b_A[n - 1] /= b_A[jj];
      }
    }

    n = 4 - j;
    iy = b + 6;
    jA = jj;
    for (b = 0; b <= n; b++) {
      smax = b_A[iy];
      if (b_A[iy] != 0.0) {
        ix = jj + 1;
        i10 = jA + 8;
        i11 = (jA - j) + 12;
        for (jp1j = i10; jp1j <= i11; jp1j++) {
          b_A[jp1j - 1] += b_A[ix] * -smax;
          ix++;
        }
      }

      iy += 6;
      jA += 6;
    }

    if (ipiv[j] != j + 1) {
      for (iy = 0; iy < 6; iy++) {
        jA = j + 6 * iy;
        smax = B[jA];
        i10 = (ipiv[j] + 6 * iy) - 1;
        B[jA] = B[i10];
        B[i10] = smax;
      }
    }
  }

  for (j = 0; j < 6; j++) {
    iy = 6 * j;
    for (k = 0; k < 6; k++) {
      jA = 6 * k;
      i10 = k + iy;
      if (B[i10] != 0.0) {
        i11 = k + 2;
        for (n = i11; n < 7; n++) {
          b = (n + iy) - 1;
          B[b] -= B[i10] * b_A[(n + jA) - 1];
        }
      }
    }
  }

  for (j = 0; j < 6; j++) {
    iy = 6 * j;
    for (k = 5; k >= 0; k--) {
      jA = 6 * k;
      i10 = k + iy;
      smax = B[i10];
      if (smax != 0.0) {
        B[i10] = smax / b_A[k + jA];
        for (n = 0; n < k; n++) {
          i11 = n + iy;
          B[i11] -= B[i10] * b_A[n + jA];
        }
      }
    }
  }
}

/*
 * File trailer for mldivide.c
 *
 * [EOF]
 */
