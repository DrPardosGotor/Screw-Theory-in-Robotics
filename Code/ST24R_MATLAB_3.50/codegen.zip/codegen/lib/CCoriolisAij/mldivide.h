/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: mldivide.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 10-Mar-2019 20:59:05
 */

#ifndef MLDIVIDE_H
#define MLDIVIDE_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "CCoriolisAij_types.h"

/* Function Declarations */
extern void mldivide(const double A[36], double B[36]);

#endif

/*
 * File trailer for mldivide.h
 *
 * [EOF]
 */
