/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: svd1.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 25-Aug-2019 20:35:55
 */

#ifndef SVD1_H
#define SVD1_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "F187_ST24R_IIWA14_IKDK_OnLineJThe_types.h"

/* Function Declarations */
extern void svd(const double A[9], double U[9], double s[3], double V[9]);

#endif

/*
 * File trailer for svd1.h
 *
 * [EOF]
 */
