//
// Prerelease License - for engineering feedback and testing purposes
// only. Not for sale.
// File: Aij2adjoint.cpp
//
// MATLAB Coder version            : 4.2
// C/C++ source code generated on  : 04-Mar-2019 19:11:06
//

// Include Files
#include <string.h>
#include "rt_nonfinite.h"
#include "Fcn_ABBIRB120_ID_ToolD.h"
#include "Aij2adjoint.h"
#include "mldivide.h"
#include "expScrew.h"
#include "Fcn_ABBIRB120_ID_ToolD_data.h"

// Function Definitions

//
// Arguments    : double i
//                double j
//                const double TwMag[42]
//                double Ad[36]
// Return Type  : void
//
void Aij2adjoint(double i, double j, const double TwMag[42], double Ad[36])
{
  double PoE[16];
  int i4;
  int k;
  double dv6[16];
  int PoE_tmp;
  double b_PoE[16];
  int i5;
  int i6;
  double dv7[9];
  double c_PoE[36];
  double dv8[9];

  //  "AIJ2ADJOINT" Computes ADJOINT TRANSFORMATION for list of twists-mag.
  //  Use in SE(3).
  //  Notation useful for Link Jacobian (mobile).
  //  Notation useful for Christofell Symbols.
  //  Use in SE(3).
  //
  //  	Ad = Aij2adjoint(i,j,TwMag)
  //
  //  INPUTS:
  //  TwMag = [Tw1; Mag1, ..., Twn; Magn] (7xn)
  //  for each rigid body joint (link 1..n).
  //  Twn1..Twn6: The TWIST components for the joint SCREW movement.
  //  Magn: The MAGNITUDE component for the joint SCREW movement.
  //
  //  ADJOINT TRANSFORMATION: This is a special notation which gives us a most
  //  form of the Adjoint of an open chain manipulator
  //  We use this notation for an easy calculation of the Manipulator Inertia
  //  Matrix and the Manipulator Coriolis Matrix.
  //  Computes the Adg in R^6 (6x6 matrix) from any robot link.
  //       I                                    if i=j
  //  Aij= Ad^-1[(exp(Ej+1,Tj+1)...(exp(Ei,Ti)] if i>j
  //       0                                    if i<j
  //
  //  See also: tform2adjoint, expScrew.
  //
  //  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor.
  //
  //  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB
  //
  //  ST24R is free software: you can redistribute it and/or modify
  //  it under the terms of the GNU Lesser General Public License as published
  //  by the Free Software Foundation, either version 3 of the License, or
  //  (at your option) any later version.
  //
  //  ST24R is distributed in the hope that it will be useful,
  //  but WITHOUT ANY WARRANTY; without even the implied warranty of
  //  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  //  GNU Lesser General Public License for more details.
  //
  //  You should have received a copy of the GNU Leser General Public License
  //  along with ST24R.  If not, see <http://www.gnu.org/licenses/>.
  //
  //  http://www.
  //
  //  CHANGES:
  //  Revision 1.1  2019/02/11 00:00:01
  //  General cleanup of code: help comments, see also, copyright
  //  references, clarification of functions.
  //
  //  	Ad = Aij2adjoint(i,j,TwMag)
  //
  memset(&Ad[0], 0, 36U * sizeof(double));
  if (!(i < j)) {
    if (i == j) {
      for (i4 = 0; i4 < 36; i4++) {
        Ad[i4] = iv1[i4];
      }
    } else {
      expScrew(*(double (*)[7])&TwMag[7 * (static_cast<int>((j + 1.0)) - 1)],
               PoE);
      i4 = static_cast<int>((i + (1.0 - (j + 2.0))));
      for (k = 0; k < i4; k++) {
        expScrew(*(double (*)[7])&TwMag[7 * (static_cast<int>(((j + 2.0) +
                    static_cast<double>(k))) - 1)], dv6);
        for (PoE_tmp = 0; PoE_tmp < 4; PoE_tmp++) {
          for (i5 = 0; i5 < 4; i5++) {
            i6 = i5 << 2;
            b_PoE[PoE_tmp + i6] = ((PoE[PoE_tmp] * dv6[i6] + PoE[PoE_tmp + 4] *
              dv6[1 + i6]) + PoE[PoE_tmp + 8] * dv6[2 + i6]) + PoE[PoE_tmp + 12]
              * dv6[3 + i6];
          }
        }

        memcpy(&PoE[0], &b_PoE[0], sizeof(double) << 4);
      }

      //
      //  "TFORM2ADJOINT" Find the adjoint matrix associated with a tform.
      //  Use in SE(3).
      //
      //  	Ad = tform2adjoint(tform)
      //
      //  ADJOINT TRANSFORMATION:
      //  it is used to transforms twist from one coordinate frame to another.
      //  Vs =Adg*Vb ; Vac = Adgab*Vbc ; E'=Adg*E
      //  The adjoint transformation maps twist vectors to twist vectors.
      //  Compute the Adg in R^6 (6x6 matrix9 from the homogeneous matrix g 4x4. 
      //       |R p^R|            |R p|
      //  Adg =|     | <= tform = |   |
      //       |0   R|            |0 1|
      //  With p^=axis2skew(p)
      //
      //  See also: axis2skew,
      //
      //  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor.
      //
      //  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB 
      //
      //  ST24R is free software: you can redistribute it and/or modify
      //  it under the terms of the GNU Lesser General Public License as published 
      //  by the Free Software Foundation, either version 3 of the License, or
      //  (at your option) any later version.
      //
      //  ST24R is distributed in the hope that it will be useful,
      //  but WITHOUT ANY WARRANTY; without even the implied warranty of
      //  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
      //  GNU Lesser General Public License for more details.
      //
      //  You should have received a copy of the GNU Leser General Public License 
      //  along with ST24R.  If not, see <http://www.gnu.org/licenses/>.
      //
      //  http://www.
      //
      //  CHANGES:
      //  Revision 1.1  2019/02/11 00:00:01
      //  General cleanup of code: help comments, see also, copyright
      //  references, clarification of functions.
      //
      //  	Ad = tform2adjoint(tform)
      //
      //  "axis2skew" Generate a skew symmetric matrix from a vector (axis) .
      //  Use in SO(3).
      //
      //  	r = axis2skew(w)
      //
      //  Returns a skew symmetric matrix r 3x3 from the vector 3x1 w[a1;a2;a3;]. 
      //     |0  -a3  a2|
      //  r =|a3   0 -a1|
      //     |-a2 a1   0|
      //
      //  See also: skew2axis.
      //
      //  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor.
      //
      //  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB 
      //
      //  ST24R is free software: you can redistribute it and/or modify
      //  it under the terms of the GNU Lesser General Public License as published 
      //  by the Free Software Foundation, either version 3 of the License, or
      //  (at your option) any later version.
      //
      //  ST24R is distributed in the hope that it will be useful,
      //  but WITHOUT ANY WARRANTY; without even the implied warranty of
      //  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
      //  GNU Lesser General Public License for more details.
      //
      //  You should have received a copy of the GNU Leser General Public License 
      //  along with ST24R.  If not, see <http://www.gnu.org/licenses/>.
      //
      //  http://www.
      //
      //  CHANGES:
      //  Revision 1.1  2019/02/11 00:00:01
      //  General cleanup of code: help comments, see also, copyright
      //  references, clarification of functions.
      //
      //  r = axis2skew(w)
      //
      //
      for (i4 = 0; i4 < 36; i4++) {
        Ad[i4] = iv1[i4];
      }

      dv7[0] = 0.0;
      dv7[3] = -PoE[14];
      dv7[6] = PoE[13];
      dv7[1] = PoE[14];
      dv7[4] = 0.0;
      dv7[7] = -PoE[12];
      dv7[2] = -PoE[13];
      dv7[5] = PoE[12];
      dv7[8] = 0.0;
      for (i4 = 0; i4 < 3; i4++) {
        for (PoE_tmp = 0; PoE_tmp < 3; PoE_tmp++) {
          i5 = PoE_tmp << 2;
          dv8[i4 + 3 * PoE_tmp] = (dv7[i4] * PoE[i5] + dv7[i4 + 3] * PoE[1 + i5])
            + dv7[i4 + 6] * PoE[2 + i5];
          c_PoE[PoE_tmp + 6 * i4] = PoE[PoE_tmp + (i4 << 2)];
        }
      }

      for (i4 = 0; i4 < 3; i4++) {
        k = 6 * (i4 + 3);
        c_PoE[k] = dv8[3 * i4];
        c_PoE[6 * i4 + 3] = 0.0;
        PoE_tmp = i4 << 2;
        c_PoE[k + 3] = PoE[PoE_tmp];
        c_PoE[1 + k] = dv8[1 + 3 * i4];
        c_PoE[6 * i4 + 4] = 0.0;
        c_PoE[k + 4] = PoE[1 + PoE_tmp];
        c_PoE[2 + k] = dv8[2 + 3 * i4];
        c_PoE[6 * i4 + 5] = 0.0;
        c_PoE[k + 5] = PoE[2 + PoE_tmp];
      }

      mldivide(c_PoE, Ad);
    }
  }

  //
  //
}

//
// File trailer for Aij2adjoint.cpp
//
// [EOF]
//
