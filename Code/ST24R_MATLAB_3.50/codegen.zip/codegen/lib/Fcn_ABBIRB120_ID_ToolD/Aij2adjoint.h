//
// Prerelease License - for engineering feedback and testing purposes
// only. Not for sale.
// File: Aij2adjoint.h
//
// MATLAB Coder version            : 4.2
// C/C++ source code generated on  : 04-Mar-2019 19:11:06
//
#ifndef AIJ2ADJOINT_H
#define AIJ2ADJOINT_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "Fcn_ABBIRB120_ID_ToolD_types.h"

// Function Declarations
extern void Aij2adjoint(double i, double j, const double TwMag[42], double Ad[36]);

#endif

//
// File trailer for Aij2adjoint.h
//
// [EOF]
//
