//
// Prerelease License - for engineering feedback and testing purposes
// only. Not for sale.
// File: Christoffel.h
//
// MATLAB Coder version            : 4.2
// C/C++ source code generated on  : 04-Mar-2019 19:11:06
//
#ifndef CHRISTOFFEL_H
#define CHRISTOFFEL_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "Fcn_ABBIRB120_ID_ToolD_types.h"

// Function Declarations
extern double Christoffel(const double TwMag[42], const double LiMas[42], double
  i, double j, double k);

#endif

//
// File trailer for Christoffel.h
//
// [EOF]
//
