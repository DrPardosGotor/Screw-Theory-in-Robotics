//
// Prerelease License - for engineering feedback and testing purposes
// only. Not for sale.
// File: Fcn_ABBIRB120_ID_ToolD_data.cpp
//
// MATLAB Coder version            : 4.2
// C/C++ source code generated on  : 04-Mar-2019 19:11:06
//

// Include Files
#include "rt_nonfinite.h"
#include "Fcn_ABBIRB120_ID_ToolD.h"
#include "Fcn_ABBIRB120_ID_ToolD_data.h"

// Variable Definitions
const signed char iv0[9] = { 1, 0, 0, 0, 1, 0, 0, 0, 1 };

const signed char iv1[36] = { 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0,
  0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1 };

//
// File trailer for Fcn_ABBIRB120_ID_ToolD_data.cpp
//
// [EOF]
//
