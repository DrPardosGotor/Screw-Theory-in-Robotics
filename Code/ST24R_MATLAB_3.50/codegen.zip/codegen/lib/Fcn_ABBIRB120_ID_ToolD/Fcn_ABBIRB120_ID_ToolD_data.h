//
// Prerelease License - for engineering feedback and testing purposes
// only. Not for sale.
// File: Fcn_ABBIRB120_ID_ToolD_data.h
//
// MATLAB Coder version            : 4.2
// C/C++ source code generated on  : 04-Mar-2019 19:11:06
//
#ifndef FCN_ABBIRB120_ID_TOOLD_DATA_H
#define FCN_ABBIRB120_ID_TOOLD_DATA_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "Fcn_ABBIRB120_ID_ToolD_types.h"

// Variable Declarations
extern const signed char iv0[9];
extern const signed char iv1[36];

#endif

//
// File trailer for Fcn_ABBIRB120_ID_ToolD_data.h
//
// [EOF]
//
