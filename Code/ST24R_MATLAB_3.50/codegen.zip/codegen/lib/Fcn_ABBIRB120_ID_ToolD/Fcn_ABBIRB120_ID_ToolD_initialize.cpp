//
// Prerelease License - for engineering feedback and testing purposes
// only. Not for sale.
// File: Fcn_ABBIRB120_ID_ToolD_initialize.cpp
//
// MATLAB Coder version            : 4.2
// C/C++ source code generated on  : 04-Mar-2019 19:11:06
//

// Include Files
#include "rt_nonfinite.h"
#include "Fcn_ABBIRB120_ID_ToolD.h"
#include "Fcn_ABBIRB120_ID_ToolD_initialize.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void Fcn_ABBIRB120_ID_ToolD_initialize()
{
  rt_InitInfAndNaN(8U);
}

//
// File trailer for Fcn_ABBIRB120_ID_ToolD_initialize.cpp
//
// [EOF]
//
