//
// Prerelease License - for engineering feedback and testing purposes
// only. Not for sale.
// File: Fcn_ABBIRB120_ID_ToolD_initialize.h
//
// MATLAB Coder version            : 4.2
// C/C++ source code generated on  : 04-Mar-2019 19:11:06
//
#ifndef FCN_ABBIRB120_ID_TOOLD_INITIALIZE_H
#define FCN_ABBIRB120_ID_TOOLD_INITIALIZE_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "Fcn_ABBIRB120_ID_ToolD_types.h"

// Function Declarations
extern void Fcn_ABBIRB120_ID_ToolD_initialize();

#endif

//
// File trailer for Fcn_ABBIRB120_ID_ToolD_initialize.h
//
// [EOF]
//
