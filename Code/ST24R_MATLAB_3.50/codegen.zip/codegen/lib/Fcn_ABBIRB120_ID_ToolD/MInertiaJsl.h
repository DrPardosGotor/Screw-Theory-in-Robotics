//
// Prerelease License - for engineering feedback and testing purposes
// only. Not for sale.
// File: MInertiaJsl.h
//
// MATLAB Coder version            : 4.2
// C/C++ source code generated on  : 04-Mar-2019 19:11:06
//
#ifndef MINERTIAJSL_H
#define MINERTIAJSL_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "Fcn_ABBIRB120_ID_ToolD_types.h"

// Function Declarations
extern void MInertiaJsl(const double TwMag[42], const double LiMas[42], double
  Mt[36]);

#endif

//
// File trailer for MInertiaJsl.h
//
// [EOF]
//
