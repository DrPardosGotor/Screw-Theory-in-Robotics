//
// Prerelease License - for engineering feedback and testing purposes
// only. Not for sale.
// File: expScrew.h
//
// MATLAB Coder version            : 4.2
// C/C++ source code generated on  : 04-Mar-2019 19:11:06
//
#ifndef EXPSCREW_H
#define EXPSCREW_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "Fcn_ABBIRB120_ID_ToolD_types.h"

// Function Declarations
extern void expScrew(const double TwMag[7], double H[16]);

#endif

//
// File trailer for expScrew.h
//
// [EOF]
//
