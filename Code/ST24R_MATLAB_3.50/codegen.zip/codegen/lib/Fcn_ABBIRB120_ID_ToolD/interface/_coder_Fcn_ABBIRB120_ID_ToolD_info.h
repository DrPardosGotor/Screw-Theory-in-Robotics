/* 
 * Prerelease License - for engineering feedback and testing purposes 
 * only. Not for sale. 
 * File: _coder_Fcn_ABBIRB120_ID_ToolD_info.h 
 *  
 * MATLAB Coder version            : 4.2 
 * C/C++ source code generated on  : 04-Mar-2019 19:11:06 
 */

#ifndef _CODER_FCN_ABBIRB120_ID_TOOLD_INFO_H
#define _CODER_FCN_ABBIRB120_ID_TOOLD_INFO_H
/* Include Files */ 
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */ 
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo();
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties();

#endif
/* 
 * File trailer for _coder_Fcn_ABBIRB120_ID_ToolD_info.h 
 *  
 * [EOF] 
 */
