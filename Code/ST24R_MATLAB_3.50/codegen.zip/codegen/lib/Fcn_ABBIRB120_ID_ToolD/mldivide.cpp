//
// Prerelease License - for engineering feedback and testing purposes
// only. Not for sale.
// File: mldivide.cpp
//
// MATLAB Coder version            : 4.2
// C/C++ source code generated on  : 04-Mar-2019 19:11:06
//

// Include Files
#include <string.h>
#include "rt_nonfinite.h"
#include "Fcn_ABBIRB120_ID_ToolD.h"
#include "mldivide.h"
#include "xgetrf.h"

// Function Definitions

//
// Arguments    : const double A[36]
//                double B[36]
// Return Type  : void
//
void mldivide(const double A[36], double B[36])
{
  double b_A[36];
  int ipiv[6];
  int info;
  int jBcol;
  int temp_tmp;
  double temp;
  int kAcol;
  int i13;
  int i14;
  int i;
  int i15;
  memcpy(&b_A[0], &A[0], 36U * sizeof(double));
  xgetrf(b_A, ipiv, &info);
  for (info = 0; info < 5; info++) {
    if (ipiv[info] != info + 1) {
      for (jBcol = 0; jBcol < 6; jBcol++) {
        temp_tmp = info + 6 * jBcol;
        temp = B[temp_tmp];
        i13 = (ipiv[info] + 6 * jBcol) - 1;
        B[temp_tmp] = B[i13];
        B[i13] = temp;
      }
    }
  }

  for (info = 0; info < 6; info++) {
    jBcol = 6 * info;
    for (temp_tmp = 0; temp_tmp < 6; temp_tmp++) {
      kAcol = 6 * temp_tmp;
      i13 = temp_tmp + jBcol;
      if (B[i13] != 0.0) {
        i14 = temp_tmp + 2;
        for (i = i14; i < 7; i++) {
          i15 = (i + jBcol) - 1;
          B[i15] -= B[i13] * b_A[(i + kAcol) - 1];
        }
      }
    }
  }

  for (info = 0; info < 6; info++) {
    jBcol = 6 * info;
    for (temp_tmp = 5; temp_tmp >= 0; temp_tmp--) {
      kAcol = 6 * temp_tmp;
      i13 = temp_tmp + jBcol;
      temp = B[i13];
      if (temp != 0.0) {
        B[i13] = temp / b_A[temp_tmp + kAcol];
        for (i = 0; i < temp_tmp; i++) {
          i14 = i + jBcol;
          B[i14] -= B[i13] * b_A[i + kAcol];
        }
      }
    }
  }
}

//
// File trailer for mldivide.cpp
//
// [EOF]
//
