//
// Prerelease License - for engineering feedback and testing purposes
// only. Not for sale.
// File: norm.cpp
//
// MATLAB Coder version            : 4.2
// C/C++ source code generated on  : 04-Mar-2019 19:11:06
//

// Include Files
#include <cmath>
#include "rt_nonfinite.h"
#include "Fcn_ABBIRB120_ID_ToolD.h"
#include "norm.h"

// Function Definitions

//
// Arguments    : const double x[3]
// Return Type  : double
//
double b_norm(const double x[3])
{
  double y;
  double scale;
  double absxk;
  double t;
  scale = 3.3121686421112381E-170;
  absxk = std::abs(x[0]);
  if (absxk > 3.3121686421112381E-170) {
    y = 1.0;
    scale = absxk;
  } else {
    t = absxk / 3.3121686421112381E-170;
    y = t * t;
  }

  absxk = std::abs(x[1]);
  if (absxk > scale) {
    t = scale / absxk;
    y = 1.0 + y * t * t;
    scale = absxk;
  } else {
    t = absxk / scale;
    y += t * t;
  }

  absxk = std::abs(x[2]);
  if (absxk > scale) {
    t = scale / absxk;
    y = 1.0 + y * t * t;
    scale = absxk;
  } else {
    t = absxk / scale;
    y += t * t;
  }

  return scale * std::sqrt(y);
}

//
// File trailer for norm.cpp
//
// [EOF]
//
