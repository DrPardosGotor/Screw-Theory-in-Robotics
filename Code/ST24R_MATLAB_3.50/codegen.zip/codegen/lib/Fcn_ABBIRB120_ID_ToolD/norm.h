//
// Prerelease License - for engineering feedback and testing purposes
// only. Not for sale.
// File: norm.h
//
// MATLAB Coder version            : 4.2
// C/C++ source code generated on  : 04-Mar-2019 19:11:06
//
#ifndef NORM_H
#define NORM_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "Fcn_ABBIRB120_ID_ToolD_types.h"

// Function Declarations
extern double b_norm(const double x[3]);

#endif

//
// File trailer for norm.h
//
// [EOF]
//
