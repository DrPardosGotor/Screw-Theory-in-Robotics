/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: MInertiaJsl.c
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 10-Mar-2019 21:07:29
 */

/* Include Files */
#include <string.h>
#include "MInertiaJsl.h"
#include "xgetrf.h"
#include "expScrew.h"

/* Function Definitions */

/*
 * Arguments    : const double TwMag[49]
 *                const double LiMas[49]
 *                double Mt[49]
 * Return Type  : void
 */
void MInertiaJsl(const double TwMag[49], const double LiMas[49], double Mt[49])
{
  int i;
  double Hsli0[16];
  double dv0[9];
  int i0;
  int i1;
  int AdHsli0_tmp;
  int j;
  double AdHsli0[36];
  double dv1[9];
  int temp;
  double b_temp;
  static const signed char b[9] = { 1, 0, 0, 0, 1, 0, 0, 0, 1 };

  double JstL[42];
  double b_JstL[42];
  double AZ[36];
  int k;
  static const signed char AI[36] = { 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0,
    1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1 };

  double A[36];
  double dv2[16];
  int ipiv[6];
  int kAcol;
  double b_Hsli0[16];
  int temp_tmp;
  int AZ_tmp;

  /*  "MInertiaL" INERTIA MATRIX M(t) for an open chain manipulator. */
  /*  computation based on the use of the JstL Link Jacobian (mobil). */
  /*  Use in SE(3). */
  /*  */
  /*  	Mt = MInertiaJsl(TwMag,LiMas) */
  /*  */
  /*  Gives the MANIPULATOR INERTIA MATRIX M corresponding to the Lagangian's */
  /*  dynamics equations: M(t) */
  /*  M(t)*ddt + C(t,dt)*dt + N(t,dt) = T */
  /*  of the robot formed by links on an open chain.  */
  /*  */
  /*  INPUTS: */
  /*  TwMag = [Tw1; Mag1, ..., Twn; Magn] (7xn) */
  /*  for each rigid body joint (1..n). */
  /*  Tw1..Twn: The TWIST components for the joint movement. */
  /*  Mag1..Magn: The MAGNITUDE component for the joint SCREW movement. */
  /*  LiMas = [CM1; IT1; Mas1, ..., CMn; ITn; Masn] (7xn) */
  /*  for each rigid body link (1..n). */
  /*  CM1..CMn: Center of Mass x-y-z Position components to S for each Link. */
  /*  IT1..ITn: Inertia x-y-z components for each Link refered to its CM. */
  /*  Mas1..Masn: The Mass for each Link. */
  /*  Ii: Diagonal Inertia Tensor (3x3 )Ixi, Iyi, and Izi are the moments of  */
  /*  inertia about the x, y, and z-axes of the ith link frame on the CM. */
  /*  */
  /*        |M11...M1n|              i=n */
  /*  Mt =  |         |, With Mt = Sum  (JstLi'*Imi*JstLi)  */
  /*        |Mn1...Mnn|              i=1 */
  /*   */
  /*  See also: LinkInertiaL. */
  /*  */
  /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
  /*  */
  /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
  /*   */
  /*  ST24R is free software: you can redistribute it and/or modify */
  /*  it under the terms of the GNU Lesser General Public License as published */
  /*  by the Free Software Foundation, either version 3 of the License, or */
  /*  (at your option) any later version. */
  /*   */
  /*  ST24R is distributed in the hope that it will be useful, */
  /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
  /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
  /*  GNU Lesser General Public License for more details. */
  /*   */
  /*  You should have received a copy of the GNU Leser General Public License */
  /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
  /*  */
  /*  http://www. */
  /*  */
  /*  CHANGES: */
  /*  Revision 1.1  2019/02/11 00:00:01 */
  /*  General cleanup of code: help comments, see also, copyright */
  /*  references, clarification of functions. */
  /*  */
  /*  MIL = MInertiaJsl(TwMag,LiMas) */
  /*  */
  memset(&Mt[0], 0, 49U * sizeof(double));
  for (i = 0; i < 7; i++) {
    /*  */
    /*  TRVP2TFORM Convert to Homogeneous matrix a translation P vector  */
    /*   Hp = TRVP2TFORM(P) converts a translation P axis into the */
    /*   corresponding homogeneous matrix H. P is a position in longitude units. */
    /*  */
    /*    Example: */
    /*        %Calculate the homogeneous matrix for a translation p = [px;py;pz] */
    /*        on X axis. */
    /*        Hxp = trvP2tform(p) */
    /*        % Hp = [1 0 0 px; 0 1 0 py; 0 0 1 pz; 0 0 0 1]  */
    /*        ans = */
    /*                 1         0         0         px */
    /*                 0         1         0         py */
    /*                 0         0         1         pz */
    /*                 0         0         0         1 */
    /*  */
    /*  See also trvY2tform(p), trvY2tform(p), trvZ2tform(p). */
    /*  */
    /*  Copyright (C) 2003-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  Hxp = trvX2tform(pg) */
    /*  */
    Hsli0[0] = 1.0;
    Hsli0[4] = 0.0;
    Hsli0[8] = 0.0;
    Hsli0[12] = LiMas[7 * i];
    Hsli0[1] = 0.0;
    Hsli0[5] = 1.0;
    Hsli0[9] = 0.0;
    Hsli0[13] = LiMas[1 + 7 * i];
    Hsli0[2] = 0.0;
    Hsli0[6] = 0.0;
    Hsli0[10] = 1.0;
    Hsli0[14] = LiMas[2 + 7 * i];
    Hsli0[3] = 0.0;
    Hsli0[7] = 0.0;
    Hsli0[11] = 0.0;
    Hsli0[15] = 1.0;

    /*  */
    /*  */
    /*  "GeoJacobianT" computes Geometric Jacobian refered to the Link frame */
    /*  Use in SE(3). */
    /*  */
    /*  	JstL = GeoJacobianL(TwMag,Hsl0,Li) */
    /*  */
    /*  GEOMETRIC JACOBIAN in a LINK frame: At each configuration of theta, */
    /*  maps the joint velocity vector, into the corresponding velocity of the */
    /*  end effector TOOL. */
    /*  The "ith" column of jst is the "ith" joint twist, written with respect */
    /*  to the tool frame at to the currentmanipulator configuration. */
    /*  */
    /*  INPUTS: */
    /*  TwMag = [Tw1; Mag1, ..., Twn; Magn] (7xn) */
    /*  for each rigid body joint (link 1..n). */
    /*  Tw1..Twn: The TWIST components for the joint SCREW movement. */
    /*  Mag1..Magn: The MAGNITUDE component for the joint SCREW movement. */
    /*  Hsl0 is the pose of the link frame "L", associated to the Center o Mass */
    /*  at the reference (home) configuration or the manipulator. */
    /*  Li: link number. */
    /*  */
    /*  JstL = (Ad(Hsl0)^-1)*[Ai1*E1 ... Aii*Ei 0 ... 0] (6xn) */
    /*  where Aij = Aij2Adjoint and En are the Twists. */
    /*  */
    /*  See also: GeoJacobianS, GeoJacobianT, Aij2adjoint, tform2adjoint. */
    /*  */
    /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  JstL = GeoJacobianL(TwMag,Hsl0,Li) */
    /*  */
    /*  */
    /*  "TFORM2ADJOINT" Find the adjoint matrix associated with a tform. */
    /*  Use in SE(3). */
    /*  */
    /*  	Ad = tform2adjoint(tform) */
    /*  */
    /*  ADJOINT TRANSFORMATION: */
    /*  it is used to transforms twist from one coordinate frame to another. */
    /*  Vs =Adg*Vb ; Vac = Adgab*Vbc ; E'=Adg*E */
    /*  The adjoint transformation maps twist vectors to twist vectors. */
    /*  Compute the Adg in R^6 (6x6 matrix9 from the homogeneous matrix g 4x4. */
    /*       |R p^R|            |R p| */
    /*  Adg =|     | <= tform = |   | */
    /*       |0   R|            |0 1| */
    /*  With p^=axis2skew(p) */
    /*  */
    /*  See also: axis2skew, */
    /*  */
    /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  	Ad = tform2adjoint(tform) */
    /*  */
    /*  "axis2skew" Generate a skew symmetric matrix from a vector (axis) . */
    /*  Use in SO(3). */
    /*  */
    /*  	r = axis2skew(w) */
    /*  */
    /*  Returns a skew symmetric matrix r 3x3 from the vector 3x1 w[a1;a2;a3;]. */
    /*     |0  -a3  a2|  */
    /*  r =|a3   0 -a1| */
    /*     |-a2 a1   0| */
    /*  */
    /*  See also: skew2axis. */
    /*  */
    /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  r = axis2skew(w) */
    /*  */
    dv0[0] = 0.0;
    dv0[3] = -LiMas[2 + 7 * i];
    dv0[6] = LiMas[1 + 7 * i];
    dv0[1] = LiMas[2 + 7 * i];
    dv0[4] = 0.0;
    dv0[7] = -LiMas[7 * i];
    dv0[2] = -LiMas[1 + 7 * i];
    dv0[5] = LiMas[7 * i];
    dv0[8] = 0.0;
    for (i0 = 0; i0 < 3; i0++) {
      for (i1 = 0; i1 < 3; i1++) {
        AdHsli0_tmp = i1 << 2;
        dv1[i0 + 3 * i1] = (dv0[i0] * Hsli0[AdHsli0_tmp] + dv0[i0 + 3] * Hsli0[1
                            + AdHsli0_tmp]) + dv0[i0 + 6] * Hsli0[2 +
          AdHsli0_tmp];
        AdHsli0[i1 + 6 * i0] = Hsli0[i1 + (i0 << 2)];
      }
    }

    for (i0 = 0; i0 < 3; i0++) {
      AdHsli0_tmp = 6 * (i0 + 3);
      AdHsli0[AdHsli0_tmp] = dv1[3 * i0];
      AdHsli0[6 * i0 + 3] = 0.0;
      temp = i0 << 2;
      AdHsli0[AdHsli0_tmp + 3] = Hsli0[temp];
      AdHsli0[1 + AdHsli0_tmp] = dv1[1 + 3 * i0];
      AdHsli0[6 * i0 + 4] = 0.0;
      AdHsli0[AdHsli0_tmp + 4] = Hsli0[1 + temp];
      AdHsli0[2 + AdHsli0_tmp] = dv1[2 + 3 * i0];
      AdHsli0[6 * i0 + 5] = 0.0;
      AdHsli0[AdHsli0_tmp + 5] = Hsli0[2 + temp];
    }

    /*  */
    for (j = 0; j < 7; j++) {
      /*  */
      /*  "AIJ2ADJOINT" Computes ADJOINT TRANSFORMATION for list of twists-mag. */
      /*  Use in SE(3). */
      /*  Notation useful for Link Jacobian (mobile). */
      /*  Notation useful for Christofell Symbols. */
      /*  Use in SE(3). */
      /*  */
      /*  	Ad = Aij2adjoint(i,j,TwMag) */
      /*  */
      /*  INPUTS: */
      /*  TwMag = [Tw1; Mag1, ..., Twn; Magn] (7xn) */
      /*  for each rigid body joint (link 1..n). */
      /*  Twn1..Twn6: The TWIST components for the joint SCREW movement. */
      /*  Magn: The MAGNITUDE component for the joint SCREW movement. */
      /*  */
      /*  ADJOINT TRANSFORMATION: This is a special notation which gives us a most  */
      /*  form of the Adjoint of an open chain manipulator */
      /*  We use this notation for an easy calculation of the Manipulator Inertia  */
      /*  Matrix and the Manipulator Coriolis Matrix.  */
      /*  Computes the Adg in R^6 (6x6 matrix) from any robot link. */
      /*       I                                    if i=j  */
      /*  Aij= Ad^-1[(exp(Ej+1,Tj+1)...(exp(Ei,Ti)] if i>j */
      /*       0                                    if i<j */
      /*  */
      /*  See also: tform2adjoint, expScrew. */
      /*  */
      /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
      /*  */
      /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
      /*   */
      /*  ST24R is free software: you can redistribute it and/or modify */
      /*  it under the terms of the GNU Lesser General Public License as published */
      /*  by the Free Software Foundation, either version 3 of the License, or */
      /*  (at your option) any later version. */
      /*   */
      /*  ST24R is distributed in the hope that it will be useful, */
      /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
      /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
      /*  GNU Lesser General Public License for more details. */
      /*   */
      /*  You should have received a copy of the GNU Leser General Public License */
      /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
      /*  */
      /*  http://www. */
      /*  */
      /*  CHANGES: */
      /*  Revision 1.1  2019/02/11 00:00:01 */
      /*  General cleanup of code: help comments, see also, copyright */
      /*  references, clarification of functions. */
      /*  */
      /*  	Ad = Aij2adjoint(i,j,TwMag) */
      /*  */
      memset(&AZ[0], 0, 36U * sizeof(double));
      if (i >= j) {
        if (i == j) {
          for (i0 = 0; i0 < 36; i0++) {
            AZ[i0] = AI[i0];
          }
        } else {
          expScrew(*(double (*)[7])&TwMag[7 * (j + 1)], Hsli0);
          i0 = i - j;
          for (k = 0; k <= i0 - 2; k++) {
            expScrew(*(double (*)[7])&TwMag[7 * ((j + k) + 2)], dv2);
            for (i1 = 0; i1 < 4; i1++) {
              for (AdHsli0_tmp = 0; AdHsli0_tmp < 4; AdHsli0_tmp++) {
                temp = AdHsli0_tmp << 2;
                b_Hsli0[i1 + temp] = ((Hsli0[i1] * dv2[temp] + Hsli0[i1 + 4] *
                  dv2[1 + temp]) + Hsli0[i1 + 8] * dv2[2 + temp]) + Hsli0[i1 +
                  12] * dv2[3 + temp];
              }
            }

            memcpy(&Hsli0[0], &b_Hsli0[0], sizeof(double) << 4);
          }

          /*  */
          /*  "TFORM2ADJOINT" Find the adjoint matrix associated with a tform. */
          /*  Use in SE(3). */
          /*  */
          /*  	Ad = tform2adjoint(tform) */
          /*  */
          /*  ADJOINT TRANSFORMATION: */
          /*  it is used to transforms twist from one coordinate frame to another. */
          /*  Vs =Adg*Vb ; Vac = Adgab*Vbc ; E'=Adg*E */
          /*  The adjoint transformation maps twist vectors to twist vectors. */
          /*  Compute the Adg in R^6 (6x6 matrix9 from the homogeneous matrix g 4x4. */
          /*       |R p^R|            |R p| */
          /*  Adg =|     | <= tform = |   | */
          /*       |0   R|            |0 1| */
          /*  With p^=axis2skew(p) */
          /*  */
          /*  See also: axis2skew, */
          /*  */
          /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
          /*  */
          /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
          /*   */
          /*  ST24R is free software: you can redistribute it and/or modify */
          /*  it under the terms of the GNU Lesser General Public License as published */
          /*  by the Free Software Foundation, either version 3 of the License, or */
          /*  (at your option) any later version. */
          /*   */
          /*  ST24R is distributed in the hope that it will be useful, */
          /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
          /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
          /*  GNU Lesser General Public License for more details. */
          /*   */
          /*  You should have received a copy of the GNU Leser General Public License */
          /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
          /*  */
          /*  http://www. */
          /*  */
          /*  CHANGES: */
          /*  Revision 1.1  2019/02/11 00:00:01 */
          /*  General cleanup of code: help comments, see also, copyright */
          /*  references, clarification of functions. */
          /*  */
          /*  	Ad = tform2adjoint(tform) */
          /*  */
          /*  "axis2skew" Generate a skew symmetric matrix from a vector (axis) . */
          /*  Use in SO(3). */
          /*  */
          /*  	r = axis2skew(w) */
          /*  */
          /*  Returns a skew symmetric matrix r 3x3 from the vector 3x1 w[a1;a2;a3;]. */
          /*     |0  -a3  a2|  */
          /*  r =|a3   0 -a1| */
          /*     |-a2 a1   0| */
          /*  */
          /*  See also: skew2axis. */
          /*  */
          /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
          /*  */
          /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
          /*   */
          /*  ST24R is free software: you can redistribute it and/or modify */
          /*  it under the terms of the GNU Lesser General Public License as published */
          /*  by the Free Software Foundation, either version 3 of the License, or */
          /*  (at your option) any later version. */
          /*   */
          /*  ST24R is distributed in the hope that it will be useful, */
          /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
          /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
          /*  GNU Lesser General Public License for more details. */
          /*   */
          /*  You should have received a copy of the GNU Leser General Public License */
          /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
          /*  */
          /*  http://www. */
          /*  */
          /*  CHANGES: */
          /*  Revision 1.1  2019/02/11 00:00:01 */
          /*  General cleanup of code: help comments, see also, copyright */
          /*  references, clarification of functions. */
          /*  */
          /*  r = axis2skew(w) */
          /*  */
          /*  */
          dv0[0] = 0.0;
          dv0[3] = -Hsli0[14];
          dv0[6] = Hsli0[13];
          dv0[1] = Hsli0[14];
          dv0[4] = 0.0;
          dv0[7] = -Hsli0[12];
          dv0[2] = -Hsli0[13];
          dv0[5] = Hsli0[12];
          dv0[8] = 0.0;
          for (i0 = 0; i0 < 3; i0++) {
            for (i1 = 0; i1 < 3; i1++) {
              AdHsli0_tmp = i1 << 2;
              dv1[i0 + 3 * i1] = (dv0[i0] * Hsli0[AdHsli0_tmp] + dv0[i0 + 3] *
                                  Hsli0[1 + AdHsli0_tmp]) + dv0[i0 + 6] * Hsli0
                [2 + AdHsli0_tmp];
              A[i1 + 6 * i0] = Hsli0[i1 + (i0 << 2)];
            }
          }

          for (i0 = 0; i0 < 3; i0++) {
            AdHsli0_tmp = 6 * (i0 + 3);
            A[AdHsli0_tmp] = dv1[3 * i0];
            A[6 * i0 + 3] = 0.0;
            temp = i0 << 2;
            A[AdHsli0_tmp + 3] = Hsli0[temp];
            A[1 + AdHsli0_tmp] = dv1[1 + 3 * i0];
            A[6 * i0 + 4] = 0.0;
            A[AdHsli0_tmp + 4] = Hsli0[1 + temp];
            A[2 + AdHsli0_tmp] = dv1[2 + 3 * i0];
            A[6 * i0 + 5] = 0.0;
            A[AdHsli0_tmp + 5] = Hsli0[2 + temp];
          }

          xgetrf(A, ipiv, &AdHsli0_tmp);
          for (i0 = 0; i0 < 36; i0++) {
            AZ[i0] = AI[i0];
          }

          for (kAcol = 0; kAcol < 5; kAcol++) {
            if (ipiv[kAcol] != kAcol + 1) {
              for (AdHsli0_tmp = 0; AdHsli0_tmp < 6; AdHsli0_tmp++) {
                temp_tmp = kAcol + 6 * AdHsli0_tmp;
                temp = (int)AZ[temp_tmp];
                AZ_tmp = (ipiv[kAcol] + 6 * AdHsli0_tmp) - 1;
                AZ[temp_tmp] = AZ[AZ_tmp];
                AZ[AZ_tmp] = temp;
              }
            }
          }

          for (AdHsli0_tmp = 0; AdHsli0_tmp < 6; AdHsli0_tmp++) {
            temp = 6 * AdHsli0_tmp;
            for (k = 0; k < 6; k++) {
              kAcol = 6 * k;
              i0 = k + temp;
              if (AZ[i0] != 0.0) {
                i1 = k + 2;
                for (temp_tmp = i1; temp_tmp < 7; temp_tmp++) {
                  AZ_tmp = (temp_tmp + temp) - 1;
                  AZ[AZ_tmp] -= AZ[i0] * A[(temp_tmp + kAcol) - 1];
                }
              }
            }
          }

          for (AdHsli0_tmp = 0; AdHsli0_tmp < 6; AdHsli0_tmp++) {
            temp = 6 * AdHsli0_tmp;
            for (k = 5; k >= 0; k--) {
              kAcol = 6 * k;
              i0 = k + temp;
              if (AZ[i0] != 0.0) {
                AZ[i0] /= A[k + kAcol];
                for (temp_tmp = 0; temp_tmp < k; temp_tmp++) {
                  AZ_tmp = temp_tmp + temp;
                  AZ[AZ_tmp] -= AZ[i0] * A[temp_tmp + kAcol];
                }
              }
            }
          }
        }
      }

      /*  */
      /*  */
      for (i0 = 0; i0 < 6; i0++) {
        b_temp = 0.0;
        for (i1 = 0; i1 < 6; i1++) {
          b_temp += AZ[i0 + 6 * i1] * TwMag[i1 + 7 * j];
        }

        b_JstL[i0 + 6 * j] = b_temp;
      }

      memcpy(&A[0], &AdHsli0[0], 36U * sizeof(double));
      xgetrf(A, ipiv, &AdHsli0_tmp);
      for (kAcol = 0; kAcol < 5; kAcol++) {
        if (ipiv[kAcol] != kAcol + 1) {
          temp_tmp = kAcol + 6 * j;
          b_temp = b_JstL[temp_tmp];
          AdHsli0_tmp = (ipiv[kAcol] + 6 * j) - 1;
          b_JstL[temp_tmp] = b_JstL[AdHsli0_tmp];
          b_JstL[AdHsli0_tmp] = b_temp;
        }
      }

      for (k = 0; k < 6; k++) {
        kAcol = 6 * k;
        i0 = k + 6 * j;
        if (b_JstL[i0] != 0.0) {
          i1 = k + 2;
          for (temp_tmp = i1; temp_tmp < 7; temp_tmp++) {
            AdHsli0_tmp = (temp_tmp + 6 * j) - 1;
            b_JstL[AdHsli0_tmp] -= b_JstL[i0] * A[(temp_tmp + kAcol) - 1];
          }
        }
      }

      for (k = 5; k >= 0; k--) {
        kAcol = 6 * k;
        i0 = k + 6 * j;
        if (b_JstL[i0] != 0.0) {
          b_JstL[i0] /= A[k + kAcol];
          for (temp_tmp = 0; temp_tmp < k; temp_tmp++) {
            AdHsli0_tmp = temp_tmp + 6 * j;
            b_JstL[AdHsli0_tmp] -= b_JstL[i0] * A[temp_tmp + kAcol];
          }
        }
      }
    }

    /*  */
    b_temp = LiMas[6 + 7 * i];
    for (i0 = 0; i0 < 3; i0++) {
      AdHsli0[6 * i0] = b_temp * (double)b[3 * i0];
      AdHsli0_tmp = 6 * (i0 + 3);
      AdHsli0[AdHsli0_tmp] = 0.0;
      AdHsli0[6 * i0 + 3] = 0.0;
      AdHsli0[1 + 6 * i0] = b_temp * (double)b[1 + 3 * i0];
      AdHsli0[1 + AdHsli0_tmp] = 0.0;
      AdHsli0[6 * i0 + 4] = 0.0;
      AdHsli0[2 + 6 * i0] = b_temp * (double)b[2 + 3 * i0];
      AdHsli0[2 + AdHsli0_tmp] = 0.0;
      AdHsli0[6 * i0 + 5] = 0.0;
    }

    AdHsli0[21] = LiMas[3 + 7 * i];
    AdHsli0[27] = 0.0;
    AdHsli0[33] = 0.0;
    AdHsli0[22] = 0.0;
    AdHsli0[28] = LiMas[4 + 7 * i];
    AdHsli0[34] = 0.0;
    AdHsli0[23] = 0.0;
    AdHsli0[29] = 0.0;
    AdHsli0[35] = LiMas[5 + 7 * i];
    for (i0 = 0; i0 < 7; i0++) {
      for (i1 = 0; i1 < 6; i1++) {
        b_temp = 0.0;
        for (AdHsli0_tmp = 0; AdHsli0_tmp < 6; AdHsli0_tmp++) {
          b_temp += b_JstL[AdHsli0_tmp + 6 * i0] * AdHsli0[AdHsli0_tmp + 6 * i1];
        }

        JstL[i0 + 7 * i1] = b_temp;
      }

      for (i1 = 0; i1 < 7; i1++) {
        b_temp = 0.0;
        for (AdHsli0_tmp = 0; AdHsli0_tmp < 6; AdHsli0_tmp++) {
          b_temp += JstL[i0 + 7 * AdHsli0_tmp] * b_JstL[AdHsli0_tmp + 6 * i1];
        }

        AdHsli0_tmp = i0 + 7 * i1;
        Mt[AdHsli0_tmp] += b_temp;
      }
    }
  }

  /*  */
}

/*
 * File trailer for MInertiaJsl.c
 *
 * [EOF]
 */
