/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: MInertiaJsl_initialize.c
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 10-Mar-2019 21:07:29
 */

/* Include Files */
#include "MInertiaJsl.h"
#include "MInertiaJsl_initialize.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void MInertiaJsl_initialize(void)
{
}

/*
 * File trailer for MInertiaJsl_initialize.c
 *
 * [EOF]
 */
