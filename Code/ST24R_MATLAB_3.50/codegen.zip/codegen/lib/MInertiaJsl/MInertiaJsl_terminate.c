/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: MInertiaJsl_terminate.c
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 10-Mar-2019 21:07:29
 */

/* Include Files */
#include "MInertiaJsl.h"
#include "MInertiaJsl_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void MInertiaJsl_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for MInertiaJsl_terminate.c
 *
 * [EOF]
 */
