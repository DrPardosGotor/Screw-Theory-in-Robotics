/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: MInertiaJsl_terminate.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 10-Mar-2019 21:07:29
 */

#ifndef MINERTIAJSL_TERMINATE_H
#define MINERTIAJSL_TERMINATE_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "MInertiaJsl_types.h"

/* Function Declarations */
extern void MInertiaJsl_terminate(void);

#endif

/*
 * File trailer for MInertiaJsl_terminate.h
 *
 * [EOF]
 */
