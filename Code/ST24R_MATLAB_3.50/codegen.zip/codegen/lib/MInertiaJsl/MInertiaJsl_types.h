/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: MInertiaJsl_types.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 10-Mar-2019 21:07:29
 */

#ifndef MINERTIAJSL_TYPES_H
#define MINERTIAJSL_TYPES_H

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for MInertiaJsl_types.h
 *
 * [EOF]
 */
