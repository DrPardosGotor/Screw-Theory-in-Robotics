/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: _coder_MInertiaJsl_api.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 10-Mar-2019 21:07:29
 */

#ifndef _CODER_MINERTIAJSL_API_H
#define _CODER_MINERTIAJSL_API_H

/* Include Files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include <stddef.h>
#include <stdlib.h>
#include "_coder_MInertiaJsl_api.h"

/* Variable Declarations */
extern emlrtCTX emlrtRootTLSGlobal;
extern emlrtContext emlrtContextGlobal;

/* Function Declarations */
extern void MInertiaJsl(real_T TwMag[49], real_T LiMas[49], real_T Mt[49]);
extern void MInertiaJsl_api(const mxArray * const prhs[2], int32_T nlhs, const
  mxArray *plhs[1]);
extern void MInertiaJsl_atexit(void);
extern void MInertiaJsl_initialize(void);
extern void MInertiaJsl_terminate(void);
extern void MInertiaJsl_xil_shutdown(void);
extern void MInertiaJsl_xil_terminate(void);

#endif

/*
 * File trailer for _coder_MInertiaJsl_api.h
 *
 * [EOF]
 */
