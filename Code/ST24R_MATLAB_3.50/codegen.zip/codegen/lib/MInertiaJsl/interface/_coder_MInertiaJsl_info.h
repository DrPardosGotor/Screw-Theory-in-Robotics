/* 
 * Prerelease License - for engineering feedback and testing purposes 
 * only. Not for sale. 
 * File: _coder_MInertiaJsl_info.h 
 *  
 * MATLAB Coder version            : 4.2 
 * C/C++ source code generated on  : 10-Mar-2019 21:07:29 
 */

#ifndef _CODER_MINERTIAJSL_INFO_H
#define _CODER_MINERTIAJSL_INFO_H
/* Include Files */ 
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */ 
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties(void);

#endif
/* 
 * File trailer for _coder_MInertiaJsl_info.h 
 *  
 * [EOF] 
 */
