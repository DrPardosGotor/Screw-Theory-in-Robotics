/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: xgetrf.c
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 10-Mar-2019 21:07:29
 */

/* Include Files */
#include <math.h>
#include "MInertiaJsl.h"
#include "xgetrf.h"

/* Function Definitions */

/*
 * Arguments    : double A[36]
 *                int ipiv[6]
 *                int *info
 * Return Type  : void
 */
void xgetrf(double A[36], int ipiv[6], int *info)
{
  int i3;
  int j;
  int b;
  int jj;
  int jp1j;
  int n;
  int iy;
  int ix;
  double smax;
  int jA;
  double s;
  int ijA;
  for (i3 = 0; i3 < 6; i3++) {
    ipiv[i3] = 1 + i3;
  }

  *info = 0;
  for (j = 0; j < 5; j++) {
    b = j * 7;
    jj = j * 7;
    jp1j = b + 2;
    n = 6 - j;
    iy = 0;
    ix = b;
    smax = fabs(A[b]);
    for (jA = 2; jA <= n; jA++) {
      ix++;
      s = fabs(A[ix]);
      if (s > smax) {
        iy = jA - 1;
        smax = s;
      }
    }

    if (A[jj + iy] != 0.0) {
      if (iy != 0) {
        iy += j;
        ipiv[j] = iy + 1;
        ix = j;
        for (jA = 0; jA < 6; jA++) {
          smax = A[ix];
          A[ix] = A[iy];
          A[iy] = smax;
          ix += 6;
          iy += 6;
        }
      }

      i3 = (jj - j) + 6;
      for (iy = jp1j; iy <= i3; iy++) {
        A[iy - 1] /= A[jj];
      }
    } else {
      *info = j + 1;
    }

    n = 4 - j;
    iy = b + 6;
    jA = jj;
    for (b = 0; b <= n; b++) {
      smax = A[iy];
      if (A[iy] != 0.0) {
        ix = jj + 1;
        i3 = jA + 8;
        jp1j = (jA - j) + 12;
        for (ijA = i3; ijA <= jp1j; ijA++) {
          A[ijA - 1] += A[ix] * -smax;
          ix++;
        }
      }

      iy += 6;
      jA += 6;
    }
  }

  if ((*info == 0) && (!(A[35] != 0.0))) {
    *info = 6;
  }
}

/*
 * File trailer for xgetrf.c
 *
 * [EOF]
 */
