/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: NPotentialWre.c
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 10-Mar-2019 21:09:22
 */

/* Include Files */
#include <string.h>
#include "NPotentialWre.h"
#include "expScrew.h"
#include "norm.h"

/* Function Definitions */

/*
 * Arguments    : const double TwMag[49]
 *                const double LiMas[49]
 *                const double PoAcc[3]
 *                double Nt[7]
 * Return Type  : void
 */
void NPotentialWre(const double TwMag[49], const double LiMas[49], const double
                   PoAcc[3], double Nt[7])
{
  double MagnG;
  double AxisG_idx_0;
  double AxisG_idx_1;
  double AxisG_idx_2;
  int i;
  double JstS[42];
  int i0;
  int i1;
  double b_TwMag[7];
  double PoE[16];
  double tmp_data[42];
  int b_i;
  int PoE_tmp;
  int b_PoE_tmp;
  double Wrench[42];
  double dv0[16];
  double b_PoE[16];
  double dv1[9];
  double c_PoE[36];
  double dv2[9];
  double a;

  /*  "NPotentialWre" POTENTIAL matrix N(t) for an open chain manipulator. */
  /*  computation based on the use of the gravity WRENCH on the robot links. */
  /*  Use in SE(3). */
  /*  */
  /*  A N(t) new formulation in ST24R by Dr. Pardos-Gotor */
  /*  It allows to get the Potential matrix in Dynamics, avoiding */
  /*  the differentiation of the Potential Energy V(t). */
  /*  */
  /*  	Nt = NPotentialWre(TwMag,LiMas,PoAcc) */
  /*  */
  /*  Gives the POTENTIAL MATRIX N(t) for the Lagangian's equations:  */
  /*  M(t)*ddt + C(t,dt)*dt + N(t) = T */
  /*  of the dynamics of the robot formed by links on an open chain. */
  /*  It does not consider friction N(t, dt) and only gravitational N(t). */
  /*  */
  /*  INPUTS: */
  /*  TwMag = [Tw1; Mag1, ..., Twn; Magn] (7xn) */
  /*  for each rigid body joint (1..n). */
  /*  Tw1..Twn: The TWIST components for the joint movement. */
  /*  Mag1..Magn: The MAGNITUDE component for the joint SCREW movement. */
  /*  LiMas = [CM1; IT1; Mass1, ..., CMn; ITn; Massn] (7xn) */
  /*  for each rigid body link (1..n). */
  /*  CM1..CMn: Center of Mass x-y-z Position components to S for each Link. */
  /*  IT1..ITn: Inertia x-y-z components for each Link refered to its CM. */
  /*  Mass1..Massn: The Mass for each Link. */
  /*  PoAcc = Vector (3x1) with the accelerations for potential energies. */
  /*  e.g PoAcc = [0 0 -9.81] if the only acceleration is gravity on -Z axis. */
  /*  */
  /*  OUTPUTS: */
  /*  N(t) (nx1) potential matrix for the dynamics expression. */
  /*  Even though it is normally used only with the gravity on Z, the */
  /*  expression is genral for whatever selection of axes and even for other */
  /*  types of acceleration. Imagine a mobil robot in 3D (e.g. drone) or a  */
  /*  space robot with different values and directions for gravity. */
  /*  */
  /*       |Nt1|          n   */
  /*  Nt = |   |; Nti = Sum  JstSi*Tgi */
  /*       |Ntn|          1 */
  /*  */
  /*  with JstSi the Spatial Jacobian affecting the link i. */
  /*  */
  /*  with Tgi the GRAVITY WRENCH (pure translational) in the SPATIAL frame. */
  /*            |  w |      |   wg  |  |        wg          |     */
  /*  Tgi = mi*g|    |= mi*g|       |= |                    |        */
  /*            |-wxq|      |-wgxCMi|  |-wg x POE(1:i)*Hsli0|     */
  /*  wg is the gravity axis application. */
  /*  CMi center of mass for the link i, calculated for the current pose. */
  /*   */
  /*  See also: MInertiaAij, CCoriolisAij, NPotentialAij. */
  /*  See also: MInertiaJsl, NPotentialDifSym. */
  /*  */
  /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
  /*  */
  /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
  /*   */
  /*  ST24R is free software: you can redistribute it and/or modify */
  /*  it under the terms of the GNU Lesser General Public License as published */
  /*  by the Free Software Foundation, either version 3 of the License, or */
  /*  (at your option) any later version. */
  /*   */
  /*  ST24R is distributed in the hope that it will be useful, */
  /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
  /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
  /*  GNU Lesser General Public License for more details. */
  /*   */
  /*  You should have received a copy of the GNU Leser General Public License */
  /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
  /*  */
  /*  http://www. */
  /*  */
  /*  CHANGES: */
  /*  Revision 1.1  2019/02/11 00:00:01 */
  /*  General cleanup of code: help comments, see also, copyright */
  /*  references, clarification of functions. */
  /*  */
  /*  Nt = NPotentialWre(TwMag,LiMas,PoAcc) */
  /*  */
  MagnG = b_norm(PoAcc);
  AxisG_idx_0 = PoAcc[0] / MagnG;
  AxisG_idx_1 = PoAcc[1] / MagnG;
  AxisG_idx_2 = PoAcc[2] / MagnG;
  for (i = 0; i < 7; i++) {
    /*  */
    /*  TRVP2TFORM Convert to Homogeneous matrix a translation P vector  */
    /*   Hp = TRVP2TFORM(P) converts a translation P axis into the */
    /*   corresponding homogeneous matrix H. P is a position in longitude units. */
    /*  */
    /*    Example: */
    /*        %Calculate the homogeneous matrix for a translation p = [px;py;pz] */
    /*        on X axis. */
    /*        Hxp = trvP2tform(p) */
    /*        % Hp = [1 0 0 px; 0 1 0 py; 0 0 1 pz; 0 0 0 1]  */
    /*        ans = */
    /*                 1         0         0         px */
    /*                 0         1         0         py */
    /*                 0         0         1         pz */
    /*                 0         0         0         1 */
    /*  */
    /*  See also trvY2tform(p), trvY2tform(p), trvZ2tform(p). */
    /*  */
    /*  Copyright (C) 2003-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  Hxp = trvX2tform(pg) */
    /*  */
    /*  */
    /*  */
    /*  FORWARDKINEMATICSPOE Forwark Kinematics for a Rigid Body Tree by POE */
    /*  Product Of Exponentials from a Screw Theory movement. */
    /*  Use in SE(3). */
    /*  */
    /*  HstR = ForwardKinematicsPOE(TwMag) */
    /*  */
    /*  Forward kinematics compute the RELATIVE TO THE STATIONARY SYSTEM */
    /*  end-effector motion (pos & rot) into a homogeneous matrix tform(4x4) */
    /*  as a funtion of the given joints motion defined by the "Twist-Mangitude" */
    /*  of n links. */
    /*  INPUTS: */
    /*  TwMag = [Tw1; Mag1, ..., Twn; Magn] (7xn) */
    /*  for each rigid body joint (link 1..n). */
    /*  Twn1..Twn6: The TWIST components for the joint SCREW movement. */
    /*  Magn: The MAGNITUDE component for the joint SCREW movement. */
    /*  */
    /*    Example: */
    /*        %Calculate the Homogeneous Matrix RELATIVE transformation for the */
    /*        %end-effector of a robot with four links whose "Twist-Mangitude" */
    /*        %parameters are: */
    /*        TwMag1 = [xi1 t1]' = [[0 0 0 0 0 1] pi]'; */
    /*        TwMag2 = [xi2 t2]' = [[0 0 1 0 0 0] 2]'; */
    /*        TwMag3 = [xi3 t3]' = [[1 0 0 0 0 0] 3]'; */
    /*        TwMag4 = [xi4 t4]' = [[0 1 0 1 0 0] pi/4]'; */
    /*        TwMag = [TwMag1 TwMag2 TwMag3 TwMag4]; */
    /*        HstR = ForwardKinematicsPOE(TwMag) */
    /*        ans = */
    /*        -1.0000   -0.0000    0.0000   -3.0000 */
    /*         0.0000   -0.7071    0.7071   -0.7071 */
    /*              0    0.7071    0.7071    2.2929 */
    /*              0         0         0    1.0000 */
    /*  */
    /*  See also ForwardKinematicsDH(dhparams) */
    /*  */
    /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  HstR = ForwardKinematicsPOE(TwMag) */
    /*  */
    for (i0 = 0; i0 < 7; i0++) {
      b_TwMag[i0] = TwMag[i0];
    }

    expScrew(b_TwMag, PoE);
    for (b_i = 0; b_i < i; b_i++) {
      for (i0 = 0; i0 < 7; i0++) {
        b_TwMag[i0] = TwMag[i0 + 7 * (b_i + 1)];
      }

      expScrew(b_TwMag, dv0);
      for (i0 = 0; i0 < 4; i0++) {
        for (i1 = 0; i1 < 4; i1++) {
          PoE_tmp = i1 << 2;
          b_PoE[i0 + PoE_tmp] = ((PoE[i0] * dv0[PoE_tmp] + PoE[i0 + 4] * dv0[1 +
            PoE_tmp]) + PoE[i0 + 8] * dv0[2 + PoE_tmp]) + PoE[i0 + 12] * dv0[3 +
            PoE_tmp];
        }
      }

      memcpy(&PoE[0], &b_PoE[0], sizeof(double) << 4);
    }

    /*  */
    dv0[0] = 1.0;
    dv0[4] = 0.0;
    dv0[8] = 0.0;
    dv0[12] = LiMas[7 * i];
    dv0[1] = 0.0;
    dv0[5] = 1.0;
    dv0[9] = 0.0;
    dv0[13] = LiMas[1 + 7 * i];
    dv0[2] = 0.0;
    dv0[6] = 0.0;
    dv0[10] = 1.0;
    dv0[14] = LiMas[2 + 7 * i];
    dv0[3] = 0.0;
    dv0[7] = 0.0;
    dv0[11] = 0.0;
    dv0[15] = 1.0;
    for (i0 = 0; i0 < 4; i0++) {
      for (i1 = 0; i1 < 4; i1++) {
        PoE_tmp = i1 << 2;
        b_PoE[i0 + PoE_tmp] = ((PoE[i0] * dv0[PoE_tmp] + PoE[i0 + 4] * dv0[1 +
          PoE_tmp]) + PoE[i0 + 8] * dv0[2 + PoE_tmp]) + PoE[i0 + 12] * dv0[3 +
          PoE_tmp];
      }
    }

    /*  */
    /*  LINK2WRENCH gets de WRENCH from the LINK AXIS and a POINT on that axis */
    /*  Use in SE(3). */
    /*  */
    /*  where the WRENCH "fo" (6x1) has the two components f (3x1) and T (3x1) */
    /*  From AXIS (3x1) & a POINT q (3X1) on that axis AT THE REFERENCE POSITION. */
    /*  It is also necessary to indicate the type of FORCETYPE ('rot' or 'tra') */
    /*  for the function to work with both ROTATION & TRANSLATION movements. */
    /*  Use in SE(3). */
    /*  */
    /*    fo = link2wrench(ForceAxis, ForcePoint, forceType) */
    /*  */
    /*      |f|   |       0        | */
    /*  fo =| | = |                |: for only ROTATION torque. */
    /*      |T|   |    ForceAxis   | */
    /*  */
    /*      |f|   |    ForceAxis    |   */
    /*  fo =| | = |                 |: for only TRANSLATION force. */
    /*      |T|   | -ForceAxis X q  | */
    /*  */
    /*  See also: . */
    /*  */
    /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  	fo = link2wrench(ForceAxis, ForcePoint, forceType) */
    /*  */
    /*  */
    a = LiMas[6 + 7 * i] * MagnG;
    Wrench[6 * i] = a * AxisG_idx_0;
    Wrench[1 + 6 * i] = a * AxisG_idx_1;
    Wrench[2 + 6 * i] = a * AxisG_idx_2;
    Wrench[3 + 6 * i] = a * -(AxisG_idx_1 * b_PoE[14] - AxisG_idx_2 * b_PoE[13]);
    Wrench[4 + 6 * i] = a * -(AxisG_idx_2 * b_PoE[12] - AxisG_idx_0 * b_PoE[14]);
    Wrench[5 + 6 * i] = a * -(AxisG_idx_0 * b_PoE[13] - AxisG_idx_1 * b_PoE[12]);
    Nt[i] = 0.0;
  }

  for (i = 0; i < 7; i++) {
    memset(&JstS[0], 0, 42U * sizeof(double));

    /*  */
    /*  "GeoJacobianS" computes Geometric Jacobian refered to the Spatial frame */
    /*  of a robot of any number of links. */
    /*  Use in SE(3). */
    /*  */
    /*  	JstS = GeoJacobianS(TwMag) */
    /*  */
    /*  GEOMETRIC JACOBIAN in SPATIAL frame: At each configuration of theta,  */
    /*  maps the joint velocity vector into the velocity of end effector. */
    /*  The contribution of the "ith" joint velocity to the end effector velicity */
    /*  is independent of the configuration of later joints in the chain. */
    /*  Thus, the "ith" column of jst is the "ith" joint twist, transformed to */
    /*  the current manipulator configuration. */
    /*  */
    /*  INPUTS: */
    /*  TwMag = [Tw1; Mag1, ..., Twn; Magn] (7xn) */
    /*  for each rigid body joint (link 1..n). */
    /*  Twn1..Twn6: The TWIST components for the joint SCREW movement. */
    /*  Magn: The MAGNITUDE component for the joint SCREW movement. */
    /*  */
    /*                |v1 v2' ... vn'|  */
    /*  JstS(theta) = |              |    */
    /*                |w1 w2' ... wn'|   */
    /*            |vi'| */
    /*  With: Ei'=|   |=Ad                                       *Ei */
    /*            |wi'|   (exp(E1^theta1)*...*exp(Ei-1^thetai-1)) */
    /*  */
    /*  JstS(t)=Adg(t)*JstB(t) ; and Adg(t) is the Adjoint of gst(theta). */
    /*  */
    /*  See also: GeoJacobianT, expScrew,Tform2adjoint. */
    /*  */
    /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
    /*  */
    /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
    /*   */
    /*  ST24R is free software: you can redistribute it and/or modify */
    /*  it under the terms of the GNU Lesser General Public License as published */
    /*  by the Free Software Foundation, either version 3 of the License, or */
    /*  (at your option) any later version. */
    /*   */
    /*  ST24R is distributed in the hope that it will be useful, */
    /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
    /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
    /*  GNU Lesser General Public License for more details. */
    /*   */
    /*  You should have received a copy of the GNU Leser General Public License */
    /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
    /*  */
    /*  http://www. */
    /*  */
    /*  CHANGES: */
    /*  Revision 1.1  2019/02/11 00:00:01 */
    /*  General cleanup of code: help comments, see also, copyright */
    /*  references, clarification of functions. */
    /*  */
    /*  JstS = GeoJacobianS(TwMag) */
    /*  */
    for (i0 = 0; i0 <= i; i0++) {
      for (i1 = 0; i1 < 6; i1++) {
        tmp_data[i1 + 6 * i0] = TwMag[i1 + 7 * i0];
      }
    }

    for (i0 = 0; i0 < 7; i0++) {
      b_TwMag[i0] = TwMag[i0];
    }

    expScrew(b_TwMag, PoE);
    for (b_i = 0; b_i < i; b_i++) {
      /*  */
      /*  "TFORM2ADJOINT" Find the adjoint matrix associated with a tform. */
      /*  Use in SE(3). */
      /*  */
      /*  	Ad = tform2adjoint(tform) */
      /*  */
      /*  ADJOINT TRANSFORMATION: */
      /*  it is used to transforms twist from one coordinate frame to another. */
      /*  Vs =Adg*Vb ; Vac = Adgab*Vbc ; E'=Adg*E */
      /*  The adjoint transformation maps twist vectors to twist vectors. */
      /*  Compute the Adg in R^6 (6x6 matrix9 from the homogeneous matrix g 4x4. */
      /*       |R p^R|            |R p| */
      /*  Adg =|     | <= tform = |   | */
      /*       |0   R|            |0 1| */
      /*  With p^=axis2skew(p) */
      /*  */
      /*  See also: axis2skew, */
      /*  */
      /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
      /*  */
      /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
      /*   */
      /*  ST24R is free software: you can redistribute it and/or modify */
      /*  it under the terms of the GNU Lesser General Public License as published */
      /*  by the Free Software Foundation, either version 3 of the License, or */
      /*  (at your option) any later version. */
      /*   */
      /*  ST24R is distributed in the hope that it will be useful, */
      /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
      /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
      /*  GNU Lesser General Public License for more details. */
      /*   */
      /*  You should have received a copy of the GNU Leser General Public License */
      /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
      /*  */
      /*  http://www. */
      /*  */
      /*  CHANGES: */
      /*  Revision 1.1  2019/02/11 00:00:01 */
      /*  General cleanup of code: help comments, see also, copyright */
      /*  references, clarification of functions. */
      /*  */
      /*  	Ad = tform2adjoint(tform) */
      /*  */
      /*  "axis2skew" Generate a skew symmetric matrix from a vector (axis) . */
      /*  Use in SO(3). */
      /*  */
      /*  	r = axis2skew(w) */
      /*  */
      /*  Returns a skew symmetric matrix r 3x3 from the vector 3x1 w[a1;a2;a3;]. */
      /*     |0  -a3  a2|  */
      /*  r =|a3   0 -a1| */
      /*     |-a2 a1   0| */
      /*  */
      /*  See also: skew2axis. */
      /*  */
      /*  Copyright (C) 2001-2019, by Dr. Jose M. Pardos-Gotor. */
      /*  */
      /*  This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB */
      /*   */
      /*  ST24R is free software: you can redistribute it and/or modify */
      /*  it under the terms of the GNU Lesser General Public License as published */
      /*  by the Free Software Foundation, either version 3 of the License, or */
      /*  (at your option) any later version. */
      /*   */
      /*  ST24R is distributed in the hope that it will be useful, */
      /*  but WITHOUT ANY WARRANTY; without even the implied warranty of */
      /*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
      /*  GNU Lesser General Public License for more details. */
      /*   */
      /*  You should have received a copy of the GNU Leser General Public License */
      /*  along with ST24R.  If not, see <http://www.gnu.org/licenses/>. */
      /*  */
      /*  http://www. */
      /*  */
      /*  CHANGES: */
      /*  Revision 1.1  2019/02/11 00:00:01 */
      /*  General cleanup of code: help comments, see also, copyright */
      /*  references, clarification of functions. */
      /*  */
      /*  r = axis2skew(w) */
      /*  */
      /*  */
      dv1[0] = 0.0;
      dv1[3] = -PoE[14];
      dv1[6] = PoE[13];
      dv1[1] = PoE[14];
      dv1[4] = 0.0;
      dv1[7] = -PoE[12];
      dv1[2] = -PoE[13];
      dv1[5] = PoE[12];
      dv1[8] = 0.0;
      for (i0 = 0; i0 < 3; i0++) {
        for (i1 = 0; i1 < 3; i1++) {
          PoE_tmp = i1 << 2;
          dv2[i0 + 3 * i1] = (dv1[i0] * PoE[PoE_tmp] + dv1[i0 + 3] * PoE[1 +
                              PoE_tmp]) + dv1[i0 + 6] * PoE[2 + PoE_tmp];
          c_PoE[i1 + 6 * i0] = PoE[i1 + (i0 << 2)];
        }
      }

      for (i0 = 0; i0 < 3; i0++) {
        PoE_tmp = 6 * (i0 + 3);
        c_PoE[PoE_tmp] = dv2[3 * i0];
        c_PoE[6 * i0 + 3] = 0.0;
        b_PoE_tmp = i0 << 2;
        c_PoE[PoE_tmp + 3] = PoE[b_PoE_tmp];
        c_PoE[1 + PoE_tmp] = dv2[1 + 3 * i0];
        c_PoE[6 * i0 + 4] = 0.0;
        c_PoE[PoE_tmp + 4] = PoE[1 + b_PoE_tmp];
        c_PoE[2 + PoE_tmp] = dv2[2 + 3 * i0];
        c_PoE[6 * i0 + 5] = 0.0;
        c_PoE[PoE_tmp + 5] = PoE[2 + b_PoE_tmp];
      }

      for (i0 = 0; i0 < 6; i0++) {
        PoE_tmp = i0 + 6 * (1 + b_i);
        tmp_data[PoE_tmp] = 0.0;
        for (i1 = 0; i1 < 6; i1++) {
          tmp_data[PoE_tmp] += c_PoE[i0 + 6 * i1] * TwMag[i1 + 7 * (b_i + 1)];
        }
      }

      for (i0 = 0; i0 < 7; i0++) {
        b_TwMag[i0] = TwMag[i0 + 7 * (b_i + 1)];
      }

      expScrew(b_TwMag, dv0);
      for (i0 = 0; i0 < 4; i0++) {
        for (i1 = 0; i1 < 4; i1++) {
          PoE_tmp = i1 << 2;
          b_PoE[i0 + PoE_tmp] = ((PoE[i0] * dv0[PoE_tmp] + PoE[i0 + 4] * dv0[1 +
            PoE_tmp]) + PoE[i0 + 8] * dv0[2 + PoE_tmp]) + PoE[i0 + 12] * dv0[3 +
            PoE_tmp];
        }
      }

      memcpy(&PoE[0], &b_PoE[0], sizeof(double) << 4);
    }

    /*  */
    PoE_tmp = i + 1;
    for (i0 = 0; i0 < PoE_tmp; i0++) {
      for (i1 = 0; i1 < 6; i1++) {
        b_PoE_tmp = i1 + 6 * i0;
        JstS[b_PoE_tmp] = tmp_data[b_PoE_tmp];
      }
    }

    for (i0 = 0; i0 < 7; i0++) {
      MagnG = 0.0;
      for (i1 = 0; i1 < 6; i1++) {
        MagnG += JstS[i1 + 6 * i0] * Wrench[i1 + 6 * i];
      }

      Nt[i0] -= MagnG;
    }
  }

  /*  */
}

/*
 * File trailer for NPotentialWre.c
 *
 * [EOF]
 */
