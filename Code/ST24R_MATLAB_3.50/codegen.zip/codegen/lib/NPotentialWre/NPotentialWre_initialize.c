/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: NPotentialWre_initialize.c
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 10-Mar-2019 21:09:22
 */

/* Include Files */
#include "NPotentialWre.h"
#include "NPotentialWre_initialize.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void NPotentialWre_initialize(void)
{
}

/*
 * File trailer for NPotentialWre_initialize.c
 *
 * [EOF]
 */
