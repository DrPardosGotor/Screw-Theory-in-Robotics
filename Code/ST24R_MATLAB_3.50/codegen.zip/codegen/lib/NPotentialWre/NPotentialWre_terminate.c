/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: NPotentialWre_terminate.c
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 10-Mar-2019 21:09:22
 */

/* Include Files */
#include "NPotentialWre.h"
#include "NPotentialWre_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void NPotentialWre_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for NPotentialWre_terminate.c
 *
 * [EOF]
 */
