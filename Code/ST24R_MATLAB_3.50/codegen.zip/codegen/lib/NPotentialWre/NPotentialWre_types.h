/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: NPotentialWre_types.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 10-Mar-2019 21:09:22
 */

#ifndef NPOTENTIALWRE_TYPES_H
#define NPOTENTIALWRE_TYPES_H

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for NPotentialWre_types.h
 *
 * [EOF]
 */
