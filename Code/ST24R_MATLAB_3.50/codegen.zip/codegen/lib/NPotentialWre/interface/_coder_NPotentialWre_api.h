/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: _coder_NPotentialWre_api.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 10-Mar-2019 21:09:22
 */

#ifndef _CODER_NPOTENTIALWRE_API_H
#define _CODER_NPOTENTIALWRE_API_H

/* Include Files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include <stddef.h>
#include <stdlib.h>
#include "_coder_NPotentialWre_api.h"

/* Variable Declarations */
extern emlrtCTX emlrtRootTLSGlobal;
extern emlrtContext emlrtContextGlobal;

/* Function Declarations */
extern void NPotentialWre(real_T TwMag[49], real_T LiMas[49], real_T PoAcc[3],
  real_T Nt[7]);
extern void NPotentialWre_api(const mxArray * const prhs[3], int32_T nlhs, const
  mxArray *plhs[1]);
extern void NPotentialWre_atexit(void);
extern void NPotentialWre_initialize(void);
extern void NPotentialWre_terminate(void);
extern void NPotentialWre_xil_shutdown(void);
extern void NPotentialWre_xil_terminate(void);

#endif

/*
 * File trailer for _coder_NPotentialWre_api.h
 *
 * [EOF]
 */
