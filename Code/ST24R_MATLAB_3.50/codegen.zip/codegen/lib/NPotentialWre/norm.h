/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: norm.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 10-Mar-2019 21:09:22
 */

#ifndef NORM_H
#define NORM_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "NPotentialWre_types.h"

/* Function Declarations */
extern double b_norm(const double x[3]);

#endif

/*
 * File trailer for norm.h
 *
 * [EOF]
 */
