%% Function "F151_ST24R_ABBIRB1600_IK_OffLine_XLS"
% ABB IRB 1600 X120.
% Function solves INVERSE KYNEMATICS OFFLINE for a given TOOL TRAJECTORY.
% Providing Desired Solutions for Joints: POSITION, VELOCITY, ACCELERATION.
%
% by Dr. Pardos-Gotor ST24R "Screw Theory Toolbox for Robotics" MATLAB.
%
% function TrajOut = F151_ST24R_ABBIRB1600_IK_OffLine_XLS(xlsfile, Conf)
%
% INPUTS:
% The input is an excel file (7xn) with the following vectors by rows:
% t = time line sec.
% TcPx = Tool Center Point x position.
% TcPy = Tool Center Point y position.
% TcPz = Tool Center Point z position.
% q0 = Tool Rotation Quaternion escalar value s "cos(Th/2)".
% q1 = Tool Rotation Quaternion vectorial value "vx * sin(Th/2)".
% q2 = Tool Rotation Quaternion vectorial value "vy * sin(Th/2)".
% q3 = Tool Rotation Quaternion vectorial value "vz * sin(Th/2)".
% Conf = (1-4) selection for taking out one of the 4 possible solutions.
% 
% OUTPUTS:
% it is a timeseries mat file 'TrajOut' (29xn) with the trajectory for
% the TOOL and for the JOINTS (POSITION, VELOCITY, ACCELERATION) by rows:
% t(1,:) = time line sec.
% TcPx(2,:) = Tool Center Point x position.
% TcPy(3,:) = Tool Center Point y position.
% TcPz(4,:) = Tool Center Point z position.
% ToolRq0(5,:) = Tool Rotation Quaternion escalar value s.
% ToolRq1(6,:) = Tool Rotation Quaternion vectorial value vx.
% ToolRq2(7,:) = Tool Rotation Quaternion vectorial value vy.
% ToolRq2(8,:) = Tool Rotation Quaternion vectorial value vz.
% ThDes(9:14,:) Joint POSITIONS rad.
% ThpDes(15:20,:) Joint VELOCITIES rad/sec.
% ThppDes(21:26,:) Joint ACCELERATIONS rad/sec^2.
% Output respects maximum Magnitudes for the robot joints..
%
% Copyright (C) 2003-2020, by Dr. Jose M. Pardos-Gotor.
%
% This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB
% 
% ST24R is free software: you can redistribute it and/or modify
% it under the terms of the GNU Lesser General Public License as published
% by the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% ST24R is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU Lesser General Public License for more details.
% 
% You should have received a copy of the GNU Leser General Public License
% along with ST24R. If not, see <http://www.gnu.org/licenses/>.
%
% http://www.
%
% CHANGES:
% Revision 1.1  2019/02/11 00:00:01
% General cleanup of code: help comments, see also, copyright
% references, clarification of functions.
%
%% F151_ST24R_ABBIRB1600_IK_OffLine_XLS
%
function TrajOut = F151_ST24R_ABBIRB1600_IK_OffLine_XLS(xlsfile, Conf) % #codegen
%
% Mechanical characteristics of the Robot:
po=[0;0;0]; pf=[0.75;0;0.9615]; pp=[0.95;0;0.9615];
Twist = [          0   -0.4865   -0.9615         0   -0.9615         0;
                   0         0         0    0.9615         0    0.9615;
                   0    0.1500    0.1500         0    0.7500         0;
                   0         0         0    1.0000         0    1.0000;
                   0    1.0000    1.0000         0    1.0000         0;
              1.0000         0         0         0         0         0];
Hst0 = [0 0 1 0.9; 0 1 0 0; -1 0 0 0.9615;0 0 0 1];
%
% Maximum Magnitue for the robot joints POSITION rad, (by catalog).
Thmax = pi/180*[180 110 55 200 115 400];
Thmin = pi/180*[-180 -63 -235 -200 -115 -400];
% Maximum SPEED for the robot joints rad/sec, (by catalog).
Thpmax = pi/180*[150 160 170 320 400 400];
%
% Reading the TOOL trajectory from the xls file.
ToolTra = xlsread(xlsfile);
timeline = ToolTra(1,:);
trasize = size(ToolTra,2);
TrajOut = [ToolTra; zeros(18,trasize)];
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INVERSE KINEMATICS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now we solve inverse kinematics for each pose of the TOOL trajectory
for k = 1:trasize
% Calculate Homogeneous transformation for the GOAL "noap"
noap = quat2tform(TrajOut(5:8,k)');
noap(1:3,4)= TrajOut(2:4,k);

%
% Calculate the IK solutions Theta using the SCREW THEORY techniques
% and basically the PADEN-KAHAN Canonic Subproblems.
Theta = zeros(4,6);
% STEP2-1.1: Calculate Theta1.
% With "pf" on the axis of E4, E5, E6. We apply (noap*hs0^-1) to "pf"
% Doing so we get Theta1 applying the Canonic problem PADEN-KAHAN-ONE,
% because the screws E4,E5,E6 do not affect "pf" for being on their axes
% and the E2,E3 do not change the plane where "pf" moves, and so do not
% affect the calculation for Theta1 resulting the problem 
% "exp(E1^theta1)*pf = noap*hs0^-1*pf" by PK1.
% which has one solution for t11.
noapHst0if = noap*(Hst0\[pf; 1]); pk1 = noapHst0if(1:3);
t1 = PadenKahanOne(Twist(:,1), pf, pk1);
t1 = jointmag2limits(t1, Thmax(1), Thmin(1), "rot");
Theta(1:4,1) = t1;
%
% STEP2-1.2: Calculate Theta2 & Theta3.
% With "pf" on the axis of E4, E5, E6 we apply (noap*hs0^-1) to "pf" and
% the POE E1..E6 also to "pf" having already known the value for Theta1
% resulting exactly a Canonic problem PARDOS-FOUR, because the screws
% E4,E5,E6 do not affect "pf" and the E1 is known,resulting the problem
% exp(E2^theta2)*exp(E3^theta3)*pf = exp(E1^Th1)^-1*noap*gs0^-1*pf = pk1p
% which by PARDOS-FOUR has none, one or two DOUBLE solutions.
% t21-t31 & t22-t32 for each value of t11
%
E1inoapHst0if = (expScrew([Twist(:,1);Theta(1,1)]))\noapHst0if;
pk2 = E1inoapHst0if(1:3);
t2t3 = PardosGotorFour(Twist(:,2),Twist(:,3),pf,pk2);
%
t2t3(1,1) = jointmag2limits(t2t3(1,1), Thmax(2), Thmin(2), "rot");
t2t3(2,1) = jointmag2limits(t2t3(2,1), Thmax(2), Thmin(2), "rot");
t2t3(1,2) = jointmag2limits(t2t3(1,2), Thmax(3), Thmin(3), "rot");
t2t3(2,2) = jointmag2limits(t2t3(2,2), Thmax(3), Thmin(3), "rot");
Theta(1,2:3) = t2t3(1,:); Theta(2,2:3) = t2t3(1,:); 
Theta(3,2:3) = t2t3(2,:); Theta(4,2:3) = t2t3(2,:);
%
% STEP2-1.3: Calculate Theta4 & Theta5.
% With "pp" on the axis of E6 apply E3^-1*E2^-1*E1^-1*noap*gs0^-1 to "pp"
% and also the POE E4*E5*E6 to "pp" knowing already Theta3-Theta2-Theta1,
% resulting exactly a Canonic problem PADEN-KAHAN-TWO, because the screws
% E6 does not affect "pp" & Th3-Th2-Th1 known (four solutions), the problem
% exp(E4^theta4)*exp(E5^theta5)*pp = pk2p ; with
% pk2p = exp(E3^Th3)^-1*exp(E2^Th2)^-1*exp(E1^Th1)^-1*noap*gs0^-1*pp 
% which by PADEN-KAHAN-TWO has none, one or two DOUBLE solutions:
% t31,t21,t11 to t41-t51 & t42-t52 ; t31,t22,t12 to t43-t53 & t44-t54
%
noapHst0ip = noap*(Hst0\[pp; 1]); 
for i = 1:2:3
    pk3h = (expScrew([Twist(:,1);Theta(i,1)]))\noapHst0ip;
    pk3h = (expScrew([Twist(:,2);Theta(i,2)]))\pk3h;
    pk3h = (expScrew([Twist(:,3);Theta(i,3)]))\pk3h;
    pk3 = pk3h(1:3);
    t4t5 = PadenKahanTwo(Twist(:,4),Twist(:,5),pp,pk3); 
    t4t5(1,1) = jointmag2limits(t4t5(1,1), Thmax(4), Thmin(4), "rot");
    t4t5(2,1) = jointmag2limits(t4t5(2,1), Thmax(4), Thmin(4), "rot");
    t4t5(1,2) = jointmag2limits(t4t5(1,2), Thmax(5), Thmin(5), "rot");
    t4t5(2,2) = jointmag2limits(t4t5(2,2), Thmax(5), Thmin(5), "rot");
    Theta(i:i+1,4:5) = t4t5; 
end
%
% STEP2-1.4: Calculate Theta6.
% With "po" not in the axis of E6 apply E5^-1...*E1^-1*noap*gs0^-1 to "po"
% and applying E6 to "po" knowing already Theta5...Theta1 (8 solutions),
% resulting exactly a Canonic problem PADEN-KAHAN-ONE, the problem:
% exp(E6^theta6)*po = pk3p ; with
% pk3p = exp(E5^Th5)^-1*...*exp(E1^Th1)^-1*noap*gs0^-1*po 
% which by PADEN-KAHAN-ONE has none or one solution. Then for all
% Th5-Th4-Th3-Th2-Th1 known we get t61...t64:
%
noapHst0io = noap*(Hst0\[po; 1]);
for i = 1:4
    pk4h = (expScrew([Twist(:,1);Theta(i,1)]))\noapHst0io;
    pk4h = (expScrew([Twist(:,2);Theta(i,2)]))\pk4h;
    pk4h = (expScrew([Twist(:,3);Theta(i,3)]))\pk4h;
    pk4h = (expScrew([Twist(:,4);Theta(i,4)]))\pk4h;
    pk4h = (expScrew([Twist(:,5);Theta(i,5)]))\pk4h;
    pk4 = pk4h(1:3);
    t6 = PadenKahanOne(Twist(:,6), po, pk4);   
    t6 = jointmag2limits(t6, Thmax(6), Thmin(6), "rot");
    Theta(i,6) = t6;
end
%
ThDes = Theta(Conf,:);
TrajOut(9:14,k) = ThDes';
%
end
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Joint Trajectory VELOCITIES & ACCELERATIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
for k = 2:trasize
%
ThDes = TrajOut(9:14,k);
ThVal = TrajOut(9:14,k-1);
% Trajectory Desired for any joint with quadratic form:
% Th = a/2*t^2 => Thp = a*t => Thpp = a
% ttall is the maximum of minimum time for any joint trajectory at Thpmax.
% ti = 2*Thi/Thpmaxi = 2*(ThDesi-ThVali)/Thpmaxi; ttall = max(ti)
ttall = max(2*(Thpmax.^-1)*diag(abs(ThDes-ThVal)));
% Choose this ttall time for all joint to make ISOCHRONOUS trajectory. So,
% ThpDes are the VELOCITIES desired for the joints in rad/sec.
% ThpDes = a*ttall = 2*(ThDesi-ThVali)/ttall
% ThppDes ACCELERATIONS desired for the robot joints rad/sec^2.
% ThppDes = 2*(ThDesi-ThVali)/ttall^2
if ttall == 0
    ThpDes = zeros(1,6);
    ThppDes = zeros(1,6);
else
    ThpDes = 2*(ThDes-ThVal)/ttall;
    ThppDes = ThpDes/ttall;   
end
%
TrajOut(15:20,k) = ThpDes';
TrajOut(21:26,k) = ThppDes';
%
end
%
ToolTraj = timeseries(TrajOut(2:8,:),timeline);
save('TargetTra', 'ToolTraj','-v7.3');
JointTraj = timeseries(TrajOut(9:26,:),timeline);
save('JointTra', 'JointTraj','-v7.3');
%
end
%