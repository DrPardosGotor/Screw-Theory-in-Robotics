%% "F151_ST24R_ABBIRB1600_IK_OnLineJTra" IRB1600 ToolDown POSE.
%
% It solves the INVERSE KINEMATICS for any desired position & orientation
% of the TCP (noap goal) of the Robot.
% by Dr. Pardos-Gotor ST24R "Screw Theory Toolbox for Robotics" MATLAB.
%
% function ThetaOut = F151_ST24R_ABBIRB1600_IK_OnLineJTra_Cuadratic(u)
%
% The inputs "u" (7x1) are composed by the following vectors.
% "traXYZ" (3x1) desired translations for the TcP (noap - "p" goal).
% "rotXYZ" (3x1) desired rotations for TcP (noap - "noa" goal order (X+Y+Z)
% "Solutions" (1x1) is the value "Theta index" for choosing one out of 8
% possible results (Solutions = 1 to 8) for Robot Joint values
% Solutions = 9 is for sending the robot to the HOME POSITION (ThetaOut=0)
% Solutions = 12 is for sending the robot to the FREEZE POSITION.
% "ThetaOut" (t1..t6)are the magnitudes solution for the Robot Joints1..6.
%
% Mechanical characteristics of the Robot (AT REF POSITION):
% po = Origen for he STATIONARY system of reference.
% pk = point in the crossing of the DOF Th1(rot) & Th2(rot).
% pr = point in the axis of Th3(rot).
% pf = point in the crossing of the DOF Th4(rot), Th5(rot), Th6(rot).
% pp = TcP Tool Center Point
% po=[0;0;0]; pk=[0.15;0;0.4865]; pr=[0.15;0;0.9615];
% pf=[0.75;0;0.9615]; pp=[0.95;0;0.9615];
% hst0 = Tool (TcP) rot+tra at robot reference (home configuration).
% Hst0 = [1 0 0 0.95; 0 0 -1 0;0 1 0 0.9615;0 0 0 1];
%
%
% Copyright (C) 2003-2018, by Dr. Jose M. Pardos-Gotor.
%
% This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB
% 
% ST24R is free software: you can redistribute it and/or modify
% it under the terms of the GNU Lesser General Public License as published
% by the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% ST24R is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU Lesser General Public License for more details.
% 
% You should have received a copy of the GNU Leser General Public License
% along with ST24R. If not, see <http://www.gnu.org/licenses/>.
%
% http://www.
%
% CHANGES:
% Revision 1.1  2018/02/11 00:00:01
% General cleanup of code: help comments, see also, copyright
% references, clarification of functions.
%
%% F151_ST24R_ABBIRB1600_IK_OnLineJTra
%
function ThetaOut = F151_ST24R_ABBIRB1600_IK_OnLineJTra(u) %#codegen
%
n = 6;
persistent Theta ThetaNUM;
if isempty(Theta)
   Theta = zeros(6,n);
end
if isempty(ThetaNUM)
   ThetaNUM = 1;
end
%
% Now we read the DashBoard for checking the solution choosen
% If "Solutions" = u(7) = 1..4 then choosing Theta1..Theta4 Solutions
% If "Solutions" = u(7) = 5 then robot to HOME position and Theta(5) = 0
% If "Solutions" = u(7) = 6 then robot FREEZE to last position Theta(6).
if u(7)<=5
    ThetaNUM = u(7);
end
%
if u(7)==6
    Theta(6,:) = Theta(ThetaNUM,:);
    ThetaNUM = 6;
end
%
% Mechanical characteristics of the Robot:
po=[0;0;0]; pf=[0.75;0;0.9615]; pp=[0.95;0;0.9615];
Twist = [          0   -0.4865   -0.9615         0   -0.9615         0;
                   0         0         0    0.9615         0    0.9615;
                   0    0.1500    0.1500         0    0.7500         0;
                   0         0         0    1.0000         0    1.0000;
                   0    1.0000    1.0000         0    1.0000         0;
              1.0000         0         0         0         0         0];
Hst0 = [0 0 1 0.9; 0 1 0 0; -1 0 0 0.9615;0 0 0 1];
%
% Maximum Magnitue for the robot joints POSITION rad, (by catalog).
Thmax = pi/180*[180 110 55 200 115 400];
Thmin = pi/180*[-180 -63 -235 -200 -115 -400];
%
% Calculate Homogeneous transformation for the GOAL "noap"
traXYZ = u(1:3); rotXYZ = u(4:6);
noap = rotX2tform(rotXYZ(1))*rotY2tform(rotXYZ(2))*rotZ2tform(rotXYZ(3));
noap(1:3,4)= traXYZ';
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% IK solution approach PK1+PG4+PK2+PK1 subproblems cosecutively.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STEP2-1.1: Calculate Theta1.
% With "pf" on the axis of E4, E5, E6. We apply (noap*hs0^-1) to "pf"
% Doing so we get Theta1 applying the Canonic problem PADEN-KAHAN-ONE,
% because the screws E4,E5,E6 do not affect "pf" for being on their axes
% and the E2,E3 do not change the plane where "pf" moves, and so do not
% affect the calculation for Theta1 resulting the problem 
% "exp(E1^theta1)*pf = noap*hs0^-1*pf" by PK1.
% which has one solution for t11.
noapHst0if = noap*(Hst0\[pf; 1]); pk1 = noapHst0if(1:3);
t1 = PadenKahanOne(Twist(:,1), pf, pk1);
t1 = jointmag2limits(t1, Thmax(1), Thmin(1), "rot");
Theta(1:4,1) = t1;
%
% STEP2-1.2: Calculate Theta2 & Theta3.
% With "pf" on the axis of E4, E5, E6 we apply (noap*hs0^-1) to "pf" and
% the POE E1..E6 also to "pf" having already known the value for Theta1
% resulting exactly a Canonic problem PARDOS-FOUR, because the screws
% E4,E5,E6 do not affect "pf" and the E1 is known,resulting the problem
% exp(E2^theta2)*exp(E3^theta3)*pf = exp(E1^Th1)^-1*noap*gs0^-1*pf = pk1p
% which by PARDOS-FOUR has none, one or two DOUBLE solutions.
% t21-t31 & t22-t32 for each value of t11
%
E1inoapHst0if = (expScrew([Twist(:,1);Theta(1,1)]))\noapHst0if;
pk2 = E1inoapHst0if(1:3);
t2t3 = PardosGotorFour(Twist(:,2),Twist(:,3),pf,pk2);
%
t2t3(1,1) = jointmag2limits(t2t3(1,1), Thmax(2), Thmin(2), "rot");
t2t3(2,1) = jointmag2limits(t2t3(2,1), Thmax(2), Thmin(2), "rot");
t2t3(1,2) = jointmag2limits(t2t3(1,2), Thmax(3), Thmin(3), "rot");
t2t3(2,2) = jointmag2limits(t2t3(2,2), Thmax(3), Thmin(3), "rot");
Theta(1,2:3) = t2t3(1,:); Theta(2,2:3) = t2t3(1,:); 
Theta(3,2:3) = t2t3(2,:); Theta(4,2:3) = t2t3(2,:);
%
% STEP2-1.3: Calculate Theta4 & Theta5.
% With "pp" on the axis of E6 apply E3^-1*E2^-1*E1^-1*noap*gs0^-1 to "pp"
% and also the POE E4*E5*E6 to "pp" knowing already Theta3-Theta2-Theta1,
% resulting exactly a Canonic problem PADEN-KAHAN-TWO, because the screws
% E6 does not affect "pp" & Th3-Th2-Th1 known (four solutions), the problem
% exp(E4^theta4)*exp(E5^theta5)*pp = pk2p ; with
% pk2p = exp(E3^Th3)^-1*exp(E2^Th2)^-1*exp(E1^Th1)^-1*noap*gs0^-1*pp 
% which by PADEN-KAHAN-TWO has none, one or two DOUBLE solutions:
% t31,t21,t11 to t41-t51 & t42-t52 ; t31,t22,t12 to t43-t53 & t44-t54
%
noapHst0ip = noap*(Hst0\[pp; 1]); 
for i = 1:2:3
    pk3h = (expScrew([Twist(:,1);Theta(i,1)]))\noapHst0ip;
    pk3h = (expScrew([Twist(:,2);Theta(i,2)]))\pk3h;
    pk3h = (expScrew([Twist(:,3);Theta(i,3)]))\pk3h;
    pk3 = pk3h(1:3);
    t4t5 = PadenKahanTwo(Twist(:,4),Twist(:,5),pp,pk3); 
    t4t5(1,1) = jointmag2limits(t4t5(1,1), Thmax(4), Thmin(4), "rot");
    t4t5(2,1) = jointmag2limits(t4t5(2,1), Thmax(4), Thmin(4), "rot");
    t4t5(1,2) = jointmag2limits(t4t5(1,2), Thmax(5), Thmin(5), "rot");
    t4t5(2,2) = jointmag2limits(t4t5(2,2), Thmax(5), Thmin(5), "rot");
    Theta(i:i+1,4:5) = t4t5; 
end
%
% STEP2-1.4: Calculate Theta6.
% With "po" not in the axis of E6 apply E5^-1...*E1^-1*noap*gs0^-1 to "po"
% and applying E6 to "po" knowing already Theta5...Theta1 (8 solutions),
% resulting exactly a Canonic problem PADEN-KAHAN-ONE, the problem:
% exp(E6^theta6)*po = pk3p ; with
% pk3p = exp(E5^Th5)^-1*...*exp(E1^Th1)^-1*noap*gs0^-1*po 
% which by PADEN-KAHAN-ONE has none or one solution. Then for all
% Th5-Th4-Th3-Th2-Th1 known we get t61...t64:
%
noapHst0io = noap*(Hst0\[po; 1]);
for i = 1:4
    pk4h = (expScrew([Twist(:,1);Theta(i,1)]))\noapHst0io;
    pk4h = (expScrew([Twist(:,2);Theta(i,2)]))\pk4h;
    pk4h = (expScrew([Twist(:,3);Theta(i,3)]))\pk4h;
    pk4h = (expScrew([Twist(:,4);Theta(i,4)]))\pk4h;
    pk4h = (expScrew([Twist(:,5);Theta(i,5)]))\pk4h;
    pk4 = pk4h(1:3);
    t6 = PadenKahanOne(Twist(:,6), po, pk4);   
    t6 = jointmag2limits(t6, Thmax(6), Thmin(6), "rot");
    Theta(i,6) = t6;
end
%
ThetaOut = Theta(ThetaNUM,:);
%
end
%