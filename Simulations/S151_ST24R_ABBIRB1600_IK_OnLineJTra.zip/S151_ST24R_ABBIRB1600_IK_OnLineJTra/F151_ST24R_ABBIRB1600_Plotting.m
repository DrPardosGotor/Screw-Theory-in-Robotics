%% Fcn Kinematics - PLOTTING Exercise of Master Advanced Automation.
%
% function Plotting = F151_ST24R_ABBIRB1600_Plotting(S1xyz, S2xyz, S3xyz)
%
% The inputs "u" are composed by the following Signals Sxyz, each on (3x1).
% 'S1xyz' (3x1): File with TARGET translation of the desired Goal.
% 'S2xyz' (3x1): File with IIWATCP translation.
% 'S3xyz' (3x1): File with IRBTCP translation.
%
% Copyright 2019 Dr. Pardos-Gotor.
%
%% F151_ST24R_ABBIRB1600_Plotting
%
function fig1 = F151_ST24R_ABBIRB1600_Plotting(S1, S2, S3)
%
Target = load(S1);
Txyz = Target.ans;
IIWATCP = load(S2);
IIWAxyz = IIWATCP.ans;
IRBTCP = load(S3);
IRBxyz = IRBTCP.ans;
%
fig1 = plot3([0, 0, 0,],[0.01, 0.01, 0.01,],[0.01, 0.01, 0.01,],'o','LineWidth', 3,'DisplayName','Sorigin');
xlabel('X(m)');
ylabel('Y(m)');
zlabel('Z(m)');
hold on;
key = input('plot TARGET_TRAxyz?','s');
if (key == 'Y')||(key == 'y')
    plot3(Txyz(2,:), Txyz(3,:), Txyz(4,:),'Color','g','LineWidth', 3,'DisplayName','TARGET-TRAxyz');
end
%
key = input('plot IIWA_TCPxyz?','s');
if (key == 'Y')||(key == 'y')
    plot3(IIWAxyz(2,:), IIWAxyz(3,:), IIWAxyz(4,:),'Color','r','LineWidth', 3,'DisplayName','IIWA-TCPxyz');
end
key = input('plot IRB_TCPxyz?','s');
if (key == 'Y')||(key == 'y')
    plot3(IRBxyz(2,:), IRBxyz(3,:), IRBxyz(4,:),'Color','b','LineWidth', 3, 'DisplayName','IRB-TCPxyz');
end
hold off;
%
end
%