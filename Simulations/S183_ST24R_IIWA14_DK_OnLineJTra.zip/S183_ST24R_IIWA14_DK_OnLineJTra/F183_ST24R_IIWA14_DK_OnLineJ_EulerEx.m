%% Function "F183_ST24R_IIWA14_DK_OnlineJ_EulerEx"
% KUKA IIWA 14 R820 - Robot HOME Straight Up with complete dynamics.
% Function solves DIFFERENTIAL KINEMATICS in REAL TIME for robot joints.
% It applies the EULER EXPLICIT method for integration.
%
% It solves the DIFFERENTIAL KINEMATICS for desired position & orientation
% velocities of the TCP (noap goal) of the Robot.
% Actually, the aim is to calculate de Joints position without solving
% the Inverse Kinematics, but using the DIFFERENTIAL INVERSE KINEMATICS
% from the GEOMETRIC JACOBIAN (inverse) and the Tool Velocities.
% by Dr. Pardos-Gotor ST24R "Screw Theory Toolbox for Robotics" MATLAB.
%
% function ThetaOut = F183_ST24R_IIWA14_DK_OnlineJ_EulerEx(u)
%
% The inputs "u" (7x1) are composed by the following vectors.
% TargetVAL - Target Value composed by "traXYZ" and "rotXYZ" as
% "traXYZ" (3x1) translations for the TcP (noap - "p" goal) in S frame.
% "rotXYZ" (3x1) rotations for Tool (noap - "noa" (X+Y+Z)) in S frame.
% "Solutions" (1x1) is the value "Theta index" for choosing one out of 16
% Solutions = 1 to 16, for Robot Joint possible different solutions
% Solutions = 17 is for sending the robot to HOME POSITION (ThetaOut=17)
% Solutions = 18 is for sending the robot to the FREEZE POSITION.
% Solutions = 19 is for using Differential Kinematics for Theta AUTO.
%
% "ThetaOut" (t1..t7)are the magnitudes solution for the Robot Joints1..7.
% ThetaOut respects maximum Magnitude for the robot joints POSITION rad.
% Thmax = pi/180*[170 120 170 120 170 120 175];
%
% Mechanical characteristics of the Robot (AT REF HOME POSITION):
% The S Spatial system has the "Z" axis up (i.e., -g direction).
% po = Origen for he STATIONARY system of reference.
% pk = point in the crossing of the DOF Th1(rot) & Th2(rot) & Th3(rot).
% pr = point in the axis of Th4(rot) Th5(rot).
% pf = point in the crossing of the DOF Th5(rot), Th6(rot), Th7(rot).
% pp = TcP Tool Center Point
% hst0 = Tool (TcP) POSE configuration (rot+tra) at reference position. 
%
%
% Copyright (C) 2003-2019, by Dr. Jose M. Pardos-Gotor.
%
% This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB
% 
% ST24R is free software: you can redistribute it and/or modify
% it under the terms of the GNU Lesser General Public License as published
% by the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% ST24R is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU Lesser General Public License for more details.
% 
% You should have received a copy of the GNU Leser General Public License
% along with ST24R. If not, see <http://www.gnu.org/licenses/>.
%
% http://www.
%
% CHANGES:
% Revision 1.1  2019/02/11 00:00:01
% General cleanup of code: help comments, see also, copyright
% references, clarification of functions.
%
%% F183_ST24R_IIWA14_DK_OnlineJ_EulerEx
%
function ThetaOut = F183_ST24R_IIWA14_DK_OnLineJ_EulerEx(u) % #codegen
%
persistent ThetaVAL TargetVAL;
if isempty(ThetaVAL)
   ThetaVAL = zeros(1,7);
end
%
if isempty(TargetVAL)
% First Target Value is the Tool at robot Home pose.
   TargetVAL = [0 0 1.38 0 0 0];
end
%
if u(7)==17
    ThetaVAL = zeros(1,7);
    ThetaOut = ThetaVAL;
    return;
end
%
if u(7)==18
    ThetaOut = ThetaVAL;
    return;
end
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mechanical characteristics of the Robot (AT REF HOME POSITION):
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Joints TWISTS definition and TcP at home.
Twist = [0   -0.3600         0    0.7800         0   -1.1800         0;
         0         0         0         0         0         0         0;
         0         0         0         0         0         0         0;
         0         0         0         0         0         0         0;
         0    1.0000         0   -1.0000         0    1.0000         0;
    1.0000         0    1.0000         0    1.0000         0     1.000];
% Hst0 = [1 0 0 0; 0 1 0 0; 0 0 1 1.38; 0 0 0 1];
% Motion RANGE for the robot joints POSITION rad, (by catalog).
Thmax = pi/180*[170 120 170 120 170 120 175];
Thmin = -pi/180*[170 120 170 120 170 120 175];
% Maximum SPEED for the robot joints rad/sec, (by catalog).
% Thpmax = pi/180*[85 85 100 75 130 135 135];
% Thpmin = -pi/180*[85 85 100 75 130 135 135];
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INVERSE KINEMATICS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get the INPUT Tool position and rotation.
TargetREF = u(1:6);
TwMag = [Twist; ThetaVAL];
%
% Solve Inverse Kinematics to get a set of possible solutions for joint
% positions (exact or approximate). Theta Set has 16 solutions (16x7)
% From the set of solutions we choose only one to proceed.
ThetaSet =  Fcn_ST24R_IIWA14_IK_Upright(TargetREF);
%
if u(7)<=16
    ThetaVAL = ThetaSet(u(7),:);
else
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% When selector is AUTO u(7)=19 DIFFERENTIAL KINEMATICS is applied
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% from Inverse DK and then integrating with EULER Explicit Method.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The velocity for Tool Pose in spatial frame (S) rad/s.
% consider the differentiartion step size.
    vtcpS = (TargetREF(1:3) - TargetVAL(1:3)) / 0.002;
    wstSaxang =  rotm2axang(eul2rotm(TargetVAL(4:6),'XYZ')' * eul2rotm(TargetREF(4:6),'XYZ'));
    wstS = eul2rotm(TargetVAL(4:6),'XYZ') * (wstSaxang(1:3) * wstSaxang(4))' / 0.002; 
    VtS = [vtcpS wstS']';
%
% GEOMETRIC JACOBIAN.
    JstS = GeoJacobianS(TwMag);
% Using the "\" MATLAB function for getting Theta velocities.
%   ThetapMAT = JstS\[VtS(1:3)-axis2skew(VtS(4:6))*TargetVAL(1:3)'; VtS(4:6)];
% Using Moore-Penrose generalized inverse for getting Theta velocities.
    ThetapMPG = JstS'*((JstS*JstS')\[VtS(1:3)-axis2skew(VtS(4:6))*TargetVAL(1:3)'; VtS(4:6)]);
%    for i = 1:7
%        ThetapMPG(i) = jointmag2limits(ThetapMPG(i), Thpmax(i), Thpmin(i), "rot");
%    end
% Integrate Theta velocities to increse Theta position.
% consider the integration step size.
    ThetaVAL = ThetaVAL + (ThetapMPG * 0.002)';
% The theoretical Theta values are limited by the joints position limits.
    for i = 1:7
        ThetaVAL(i) = jointmag2limits(ThetaVAL(i), Thmax(i), Thmin(i), "rot");
    end
end
%
TargetVAL = TargetREF;
ThetaOut = ThetaVAL;
%
end
%