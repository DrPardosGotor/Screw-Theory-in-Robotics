%% Function "F183_ST24R_OffLineTraj_MAT"
% KUKA IIWA 14 R820 - Robot HOME Straight Up.
% Function solves INVERSE KYNEMATICS OFFLINE for a given TOOL TRAJECTORY.
% Providing Desired Solutions for Jonts: POSITION, VELOCITY & ACCELERATION.
%
% by Dr. Pardos-Gotor ST24R "Screw Theory Toolbox for Robotics" MATLAB.
%
% function TrajOut = F183_ST24R_OffLineTraj_MAT(matfile, tratime)
%
% INPUTS:
% "matfile" MATLAB file with the following structure:
% matlab.cart_traj (6xn) Cartesian Trajectory.
% TcPx = Tool Center Point x position.
% TcPy = Tool Center Point y position.
% TcPz = Tool Center Point z position.
% Toolx = Tool x rotation.
% Tooly = Tool y rotation.
% Toolz = Tool z rotation.
% matlab.stamps (1xn) time stamps.
% matlab.tsample (1x1) sample of time (0 => take tratime from matfile).
% tratime = desired time for the trajectory (0 => take tratime from matfile)
% 
% OUTPUTS:
% it is a timeseries mat file 'TrajOut' (8xn) with the trajectory for
% the TOOL by rows:
% t(1,:) = time line sec.
% TcPx(2,:) = Tool Center Point x position.
% TcPy(3,:) = Tool Center Point y position.
% TcPz(4,:) = Tool Center Point z position.
% ToolRq0(5,:) = Tool Rotation Quaternion escalar value s.
% ToolRq1(6,:) = Tool Rotation Quaternion vectorial value vx.
% ToolRq2(7,:) = Tool Rotation Quaternion vectorial value vy.
% ToolRq2(8,:) = Tool Rotation Quaternion vectorial value vz.
%
%
% Copyright (C) 2003-2020, by Dr. Jose M. Pardos-Gotor.
%
% This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB
% 
% ST24R is free software: you can redistribute it and/or modify
% it under the terms of the GNU Lesser General Public License as published
% by the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% ST24R is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU Lesser General Public License for more details.
% 
% You should have received a copy of the GNU Leser General Public License
% along with ST24R. If not, see <http://www.gnu.org/licenses/>.
%
% http://www.
%
% CHANGES:
% Revision 1.1  2019/02/11 00:00:01
% General cleanup of code: help comments, see also, copyright
% references, clarification of functions.
%
%% F183_ST24R_OffLineTraj_MAT
%
function TrajOut = F183_ST24R_OffLineTraj_MAT(matfile, tratime) % #codegen
%
% Reading the TOOL trajectory from the mat file.
DataTra = load(matfile);
ToolPos = DataTra.cart_traj(1:3,:);
ToolOri = DataTra.cart_traj(4:6,:);
%
if tratime == 0
    tstamps = DataTra.stamps;
    tratime = tstamps(1,end); 
end
tsample = tratime / size(ToolPos,2);
onesize = size((0:tsample:1),2);
%
timeline = (0:tsample:tratime+1);
trasize = size(timeline,2);
TrajOut = zeros(8,trasize);
%
TrajOut(1,:) = timeline;
%
TrajOut(2:4,1) = ToolPos(1:3,1);
TrajOut(5:8,1) = eul2quat(ToolOri(:,1)','XYZ')';
for i=1:onesize
    TrajOut(2:8,i) = TrajOut(2:8,1);
end
%
TrajOut(2:4,onesize+1:end) = ToolPos;
%

for i = onesize+1:trasize
    TrajOut(5:8,i) = eul2quat(ToolOri(:,i-onesize)','XYZ')';
% To keep the same Tool orientation througout the whole trajectory.
%    TrajOut(5:8,i) = TrajOut(5:8,1);
end
%
% ToolTraj = timeseries(TrajOut(2:8,:),timeline);
save('TargetTra', 'TrajOut','-v7.3');
%
end
%