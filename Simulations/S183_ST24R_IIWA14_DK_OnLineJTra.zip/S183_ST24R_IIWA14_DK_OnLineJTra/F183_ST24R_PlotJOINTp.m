%% Fcn Kinematics - PLOTTING Exercise of Master Advanced Automation.
%
% function Plotting = F183_ST24R_PlotJOINTp(tTheta)
%
% The input "Thetap" (8xn) is composed by the following signals:
% 'ti': row with the time for the plot series.
% 'The1p': row with the joint_01 velocity magnitude rad/sec series.
% 'The2p': row with the joint_02 velocity magnitude rad/sec series.
% 'The3p': row with the joint_03 velocity magnitude rad/sec series.
% 'The4p': row with the joint_04 velocity magnitude rad/sec series.
% 'The5p': row with the joint_05 velocity magnitude rad/sec series.
% 'The6p': row with the joint_06 velocity magnitude rad/sec series.
% 'The7p': row with the joint_07 velocity magnitude rad/sec series.
% 
%
% Use case: F183_ST24R_PlotJOINTp(tTheta)
%
% Copyright 2019 Dr. Pardos-Gotor.
%
%% F183_ST24R_PlotJOINTp
%
function fig1 = F183_ST24R_PlotJOINTp(tTheta)
%
JointSeries = load(tTheta);
JointMat = JointSeries.ans;
% Define the TimeSeries starting point 1sec.
xini = find(JointMat(1,:)>=1,1);
x = JointMat(1,xini:end);
%
ax1 = subplot(7,1,1);
y1 = JointMat(2,xini:end)*180/pi;
plot(ax1,x,y1,'g','LineWidth',2);
title(ax1,'Theta1p');
ylabel(ax1,'deg/sec');
%
ax2 = subplot(7,1,2);
y2 = JointMat(3,xini:end)*180/pi;
plot(ax2,x,y2,'g','LineWidth',2);
title(ax2,'Theta2p');
ylabel(ax2,'deg/sec');
%
ax3 = subplot(7,1,3);
y3 = JointMat(4,xini:end)*180/pi;
plot(ax3,x,y3,'g','LineWidth',2);
title(ax3,'Theta3p');
ylabel(ax3,'deg/sec');
%
ax4 = subplot(7,1,4);
y4 = JointMat(5,xini:end)*180/pi;
plot(ax4,x,y4,'g','LineWidth',2);
title(ax4,'Theta4p');
ylabel(ax4,'deg/sec');
%
ax5 = subplot(7,1,5);
y5 = JointMat(6,xini:end)*180/pi;
plot(ax5,x,y5,'g','LineWidth',2);
title(ax5,'Theta5p');
ylabel(ax5,'deg/sec');
%
ax6 = subplot(7,1,6);
y6 = JointMat(7,xini:end)*180/pi;
plot(ax6,x,y6,'g','LineWidth',2);
ylabel(ax6,'deg/sec');
%
ax7 = subplot(7,1,7);
y7 = JointMat(8,xini:end)*180/pi;
plot(ax7,x,y7,'g','LineWidth',2);
title(ax7,'Theta7p');
xlabel(ax7,'seconds');
ylabel(ax7,'deg/sec');
%
fig1 = ax1;
end
%