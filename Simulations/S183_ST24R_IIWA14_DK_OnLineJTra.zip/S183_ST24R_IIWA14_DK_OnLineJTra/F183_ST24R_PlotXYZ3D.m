%% Fcn Kinematics - PLOTTING Exercise of Master Advanced Automation.
%
% function Plotting = F183_ST24R_PlotXYZ3D(S1xyz, S2xyz)
%
% The inputs "u" are composed by the following Signals Sxyz.
% 'S1xyz' (3xn): File with TARGET translation of the desired Goal.
% 'S2xyz' (3xn): File with TCP translation.
% 
%
% Use case: F183_ST24R_PlotXYZ3D('IIWATargetTra', 'IIWATCPTra')
% IIWATargetTra = Target trajectory matlab file (8xn)
% IIWATCPTra = TCP trajectory matlab file (8xn)
% the funtion works the same, because it only takes the xyz (3xn) DATA
% included in the rows 2-4 of the mat files.
%
% Copyright 2019 Dr. Pardos-Gotor.
%
%% F183_ST24R_PlotXYZ3D
%
function fig1 = F183_ST24R_PlotXYZ3D(S1, S2)
%
Target = load(S1);
Txyz = Target.ans;
TCP = load(S2);
IIWAxyz = TCP.ans;
%
fig1 = plot3([0, 0, 0,],[0.01, 0.01, 0.01,],[0.01, 0.01, 0.01,],'o','LineWidth', 3,'DisplayName','Sorigin');
% xlim([0 1]);
% ylim([-0.5 0.5]);
% zlim([0 1.5]);
xlabel('X(m)');
ylabel('Y(m)');
zlabel('Z(m)');
hold on;
key = input('plot TARGET_TRAxyz?','s');
if (key == 'Y')||(key == 'y')
    plot3(Txyz(2,:), Txyz(3,:), Txyz(4,:),'Color','g','LineWidth', 3,'DisplayName','TARGET-TRAxyz');
end
%
key = input('plot IIWA_TCPxyz?','s');
if (key == 'Y')||(key == 'y')
    plot3(IIWAxyz(2,:), IIWAxyz(3,:), IIWAxyz(4,:),'Color','r','LineWidth', 3,'DisplayName','IIWA-TCPxyz');
end
hold off;
%
end
%