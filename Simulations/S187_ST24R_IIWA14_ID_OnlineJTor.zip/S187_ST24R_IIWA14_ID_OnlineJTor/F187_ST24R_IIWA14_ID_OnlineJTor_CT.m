%% Function "F187_ST24R_IIWA14_ID_OnlineJTor_CT"
% KUKA IIWA 14 R820 - Robot HOME Straight Up.
% Function solves INVERSE DYNAMICS with CONTROL, which
% takes into account a feedback for POSITION and VELOCITY.
%
% by Dr. Pardos-Gotor ST24R "Screw Theory Toolbox for Robotics" MATLAB.
%
% function TdynOut = F187_ST24R_IIWA14_ID_OnlineJTor_CT(Trajectory)
%
% INPUTS:
% "Trajectory" (1..35) is the desired rajectory for Robot Joints.
% Trajectory(1..7) = ThDes(1..7) Joint POSITIONS rad.
% Trajectory(8..14) = ThpDes(1..7) Joint VELOCITIES rad/sec.
% Trajectory(15..21) = ThppDes(1..7) Joint ACCELERATIONS rad/sec^2.
% Trajectory(22..28)= ThVal(1:7) Feedback of actual joints POSITIONS rad.
% Trajectory(29..35)= ThpVal(1:7) Feedback actual joints VELOCITIES rad/sec
% Trajectory respects maximum Magnitudes for the robot joints:
% Maximum POSITION for the robot joints rad, (by catalog).
% Thmax = pi/180*[170 120 170 120 170 120 175];
% Maximum SPEED for the robot joints rad/sec, (by catalog).
% Thpmax = pi/180*[85 85 100 75 130 135 135];
%
% OUTPUTS:
% "TdynOut" (t1..t7) are the TORQUES solution for the Robot Joints1..7.
% ThetaOut respects maximum Magnitudes for the robot joints.
% Maximum TORQUE for the robot joints Nm, (by catalog).
% Tdynmax = [320 320 176 176 110 40 40];
%
%
% Copyright (C) 2003-2019, by Dr. Jose M. Pardos-Gotor.
%
% This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB
% 
% ST24R is free software: you can redistribute it and/or modify
% it under the terms of the GNU Lesser General Public License as published
% by the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% ST24R is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU Lesser General Public License for more details.
% 
% You should have received a copy of the GNU Leser General Public License
% along with ST24R. If not, see <http://www.gnu.org/licenses/>.
%
% http://www.
%
% CHANGES:
% Revision 1.1  2019/02/11 00:00:01
% General cleanup of code: help comments, see also, copyright
% references, clarification of functions.
%
%% F187_ST24R_IIWA14_ID_OnlineJTor_CT
%
function TorOut = F187_ST24R_IIWA14_ID_OnlineJTor_CT(trajectory) % #codegen
%
% The S Spatial system has the "Z" axis up (i.e. -g direction).
PoAcc = [0 0 -9.80665]';
% LiMas matrix stands for "Link Mass" and is a 7x7 matrix.
LiMas = [0         0         0         0         0         0         0;
   -0.0300    0.0420    0.0300   -0.0340   -0.0210    0.0004         0;
    0.2775    0.4190    0.6945    0.8470    1.0410    1.1810    1.2810;
    0.1000    0.0180    0.0800    0.0300    0.0200    0.0050    0.0010;
    0.0900    0.0500    0.0750    0.0290    0.0180    0.0036    0.0010;
    0.0200    0.0440    0.0100    0.0100    0.0050    0.0047    0.0010;
    4.0000    4.0000    3.0000    2.7000    1.7000    1.8000    0.3000];
%
% Maximum Magnitue for the robot joints TORQUE Nm, (by catalog).
Tormax = [320 320 176 176 110 40 40];
%
% Joints TWISTS definition and TcP at home.
% pk=[0;0;0.36]; pf=[0;0;1.18]; pp=[0;0;1.38];
Twist = [0   -0.3600         0    0.7800         0   -1.1800         0;
         0         0         0         0         0         0         0;
         0         0         0         0         0         0         0;
         0         0         0         0         0         0         0;
         0    1.0000         0   -1.0000         0    1.0000         0;
    1.0000         0    1.0000         0    1.0000         0     1.000];
% Hst0 = [1 0 0 0; 0 1 0 0; 0 0 1 1.38; 0 0 0 1];
% Maximum Magnitue for the robot joints POSITION rad, (by catalog).
% Thmax = pi/180*[170 120 170 120 170 120 175];
% Maximum SPEED for the robot joints rad/sec, (by catalog).
% Thpmax = pi/180*[85 85 100 75 130 135 135];
%
% The Desired trajectory POSITION from Inverse Kinematics and Differential.
ThDes = trajectory(1:7);
% The Desired trajectory VELOCITY is defined to ZERO to easy control. It
% intends for the robot to stop at each trajectory waypoint.
%ThpDes = zeros(1,7);
ThpDes = trajectory(8:14);
% The Desired trajectory ACCELERATION is defined as the double of the
% maximum joint speed, to go from zero to maximum speed in 0.5 seconds.
%ThppDes = Thpmax * 2;
ThppDes = trajectory(15:21);
%
ThVal = trajectory(22:28);
ThpVal = trajectory(29:35);
TwMagVal = [Twist; ThVal];
%
% INVERSE DYNAMICS:
% complete algebraic solution with ST24R.
% M(t) Inertia matrix by the use of Jsl LINK Jacobian.
MtST24RJsl = MInertiaJsl_mex(TwMagVal,LiMas);
% C(t,dt) Coriolis matrix by the use of Aij Adjoint transformation.
CtdtST24RAij = CCoriolisAij_mex(TwMagVal,LiMas,ThpVal);
%CtdtST24RAij = zeros(7,7);
% N(t) NEW Potential Matrix by the use of the Spatial Jacobian.
NtST24RWre = NPotentialWre_mex(TwMagVal,LiMas,PoAcc);
% Inverse Dynamics solution for the joint TORQUES T Direct (no control).
% FEED-FORWARD contribution to joint TORQUES T.
TorFF = MtST24RJsl*ThppDes' + CtdtST24RAij*ThpVal' + NtST24RWre;
%
% CONTROL: 
% FEED-BACK contribution to joint TORQUES T.
% POSITION ERROR ThErr and position error velocity.
ThErr = ThVal - ThDes;
KpWeight = [0.3, 0.8, 0.6, 0.6, 0.3, 0.2, 0.1];
Kp = 950 * KpWeight; 
%Kp = 950 * KpWeight;
%
% VELOCITY ERROR ThpErr
ThpErr = ThpVal - ThpDes;
KvWeight = [0.3, 0.8, 0.6, 0.6, 0.3, 0.2, 0.1];
Kv = 125 * KvWeight;
%Kv = 125 * KvWeight;
%
% Torque FeedBack
TorFB = MtST24RJsl*(Kp.*ThErr + Kv.*ThpErr)';
%
%
% The total TORQUE is the sum of INVERSE DYNAMICS and CONTROL calculations.
TorTot = TorFF - TorFB;
%
% The mechanical limits for the robot torques are considered.
TorTot= min(abs(TorTot'),Tormax)*diag(sign(TorTot));
%
% The Output Torque to be applied to the joints.
TorOut = TorTot;
%
end
%