%% Function "F187_ST24R_IIWA14_IKDK_OnLineJThe"
% KUKA IIWA 14 R820 - Robot HOME Straight Up with complete dynamics.
% Function solves DIFFERENTIAL KINEMATICS in REAL TIME for robot joints.
% It applies the EULER EXPLICIT method for integration.
%
% It solves the DIFFERENTIAL KINEMATICS for desired position & orientation
% velocities of the TCP (noap goal) of the Robot.
% Actually, the aim is to calculate de Joints position without solving
% the Inverse Kinematics, but using the DIFFERENTIAL INVERSE KINEMATICS
% from the GEOMETRIC JACOBIAN (inverse) and the Tool Velocities.
% by Dr. Pardos-Gotor ST24R "Screw Theory Toolbox for Robotics" MATLAB.
%
% function ThetaOut = F187_ST24R_IIWA14_IKDK_OnLineJThe(u)
%
% The INPUTS "u" (7x1) are composed by the following vectors.
% Target Value composed by "traXYZ" and "rotXYZ" as
% "traXYZ" (3x1) translations for the TcP (noap - "p" goal) in S frame.
% "rotXYZ" (3x1) rotations for Tool (noap - "noa" (X+Y+Z)) in S frame.
% "Solutions" (1x1) is the value "Theta index" for choosing one out of 16
% Solutions = 1 to 16, for Robot Joint possible different solutions
% Solutions = 17 is for sending the robot to HOME POSITION (ThetaOut=17)
% Solutions = 18 is for sending the robot to the FREEZE POSITION.
% Solutions = 19 is for using Differential Kinematics for Theta AUTO, which
% means to calculate the INVERSE DIFFERENTIAL KINEMATICS.
%
% OUTPUTS (1,21):
% "ThetaOut" (1,7) POSITION magnitudes solution for Joints1..7.
% ThetaOut respects maximum Magnitude for the robot joints POSITION rad.
% Thmax = pi/180*[170 120 170 120 170 120 175];
% "ThetaOut" (8,14) VELOCITIES magnitudes solution for Joints1..7.
% "ThetaOut" (15,21) ACCELERATION magnitudes solution for Joints1..7.
%
% Mechanical characteristics of the Robot (AT REF HOME POSITION):
% The S Spatial system has the "Z" axis up (i.e., -g direction).
% po = Origen for he STATIONARY system of reference.
% pk = point in the crossing of the DOF Th1(rot) & Th2(rot) & Th3(rot).
% pr = point in the axis of Th4(rot) Th5(rot).
% pf = point in the crossing of the DOF Th5(rot), Th6(rot), Th7(rot).
% pp = TcP Tool Center Point
% hst0 = Tool (TcP) POSE configuration (rot+tra) at reference position. 
%
%
% Copyright (C) 2003-2019, by Dr. Jose M. Pardos-Gotor.
%
% This file is part of The ST24R "Screw Theory Toolbox for Robotics" MATLAB
% 
% ST24R is free software: you can redistribute it and/or modify
% it under the terms of the GNU Lesser General Public License as published
% by the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% ST24R is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU Lesser General Public License for more details.
% 
% You should have received a copy of the GNU Leser General Public License
% along with ST24R. If not, see <http://www.gnu.org/licenses/>.
%
% http://www.
%
% CHANGES:
% Revision 1.1  2019/02/11 00:00:01
% General cleanup of code: help comments, see also, copyright
% references, clarification of functions.
%
%% F187_ST24R_IIWA14_IKDK_OnLineJThe
%
function ThetaOut = F187_ST24R_IIWA14_IKDK_OnLineJThe(u) % #codegen
%
persistent ThetaVAL ThetapVAL;
if isempty(ThetaVAL)
    ThetaVAL = zeros(1,7);
end
if isempty(ThetapVAL)
    ThetapVAL = zeros(1,7);
end
%
if u(7)==17
    ThetaVAL = zeros(1,7);
    ThetaOut = [ThetaVAL 0 0 0 0 0 0 0 0 0 0 0 0 0 0];
    return;
end
%
if u(7)==18
    ThetaOut = [ThetaVAL 0 0 0 0 0 0 0 0 0 0 0 0 0 0];
    return;
end
if u(7)==19
    ThetaVAL = [-1.05746 0.138873 -2.06204 1.28518 -0.610222 -0.894605 0.886743];
    ThetaOut = [ThetaVAL 0 0 0 0 0 0 0 0 0 0 0 0 0 0];
    return;
end
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mechanical characteristics of the Robot (AT REF HOME POSITION):
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Joints TWISTS definition and TcP at home.
Twist = [0   -0.3600         0    0.7800         0   -1.1800         0;
         0         0         0         0         0         0         0;
         0         0         0         0         0         0         0;
         0         0         0         0         0         0         0;
         0    1.0000         0   -1.0000         0    1.0000         0;
    1.0000         0    1.0000         0    1.0000         0     1.000];
Hst0 = [1 0 0 0; 0 1 0 0; 0 0 1 1.38; 0 0 0 1];
% Motion RANGE for the robot joints POSITION rad, (by catalog).
Thmax = pi/180*[170 120 170 120 170 120 175];
Thmin = -pi/180*[170 120 170 120 170 120 175];
% Maximum SPEED for the robot joints rad/sec, (by catalog).
%Thpmax = pi/180*[85 85 100 75 130 135 135];
%
TwMag = [Twist; ThetaVAL];
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INVERSE KINEMATICS & DIFFERENTIAL KINEMATICS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Target VALUE is the current cartesian trajectory point.
% it is expressed as a Tool pose [trvX trvY trvZ rotX rotY rotZ] in Euler
% coordinates with translation X-Y-Z and orientation with scheme X-Y-Z:
% from the Forward Kinematics with the current joint position values.
HstThe = ForwardKinematicsPOE(TwMag)*Hst0;
TargetVAL = [HstThe(1:3,4)' rotm2eul(HstThe(1:3,1:3), 'XYZ')];
%
% stamp is the integration step size (seconds).
stamp = 0.0005;
%
% Target REFERENCE is the desired next cartesian trajectory point INPUT
% it is expressed as a Tool pose [trvX trvY trvZ rotX rotY rotZ] in Euler
% coordinates with translation X-Y-Z and orientation with scheme X-Y-Z:
TargetREF = u(1:6);
%
% We now solve for the THETAP VELOCITIES values.
% 
% VtS is the velocity for the Tool Pose in spatial frame (S) rad/s.
% consider the differentiartion step size.
VtS = minusposeEul(TargetVAL, TargetREF) / stamp;
%
% GEOMETRIC JACOBIAN JstS and SPATIAL TWIST VELOCITY "VstS" at current pose
JstS = GeoJacobianS(TwMag);
VstS = [VtS(1:3)-axis2skew(VtS(4:6))*TargetVAL(1:3)'; VtS(4:6)];
%
% Using Moore-Penrose generalized inverse for getting Theta velocities.
% Thetap = JstS'*((JstS*JstS')\VstS;
% Thetap = pinv(JstS)*VstS; it is giving worse results.
Thetap = (JstS\VstS)';
%
% The Theta VELOCITIES values are limited by the joints spped limits.
%Thetap = min(abs(Thetap),Thpmax)*diag(sign(Thetap));
%
% The Theta ACCELERATION is calculated with reference to Theta VELOCITIES.
%Thetapp = (Thetap - ThetapVAL) / stamp;
Thetapp = (Thetap - ThetapVAL) / 2;
%
% Now we solve for the NEW THETA POSITION values.
%
if u(7)<=16
% Solve Inverse Kinematics to get a set of possible solutions for joint
% positions (exact or approximate). Theta Set has 16 solutions (16x7)
% From the set of solutions we choose only one to proceed.
% Theta VALUE is the new joint positions vector (1x7) OUTPUT
    ThetaSet =  Fcn_ST24R_IIWA14_IK_Upright(TargetREF);
    ThetaVALnew = ThetaSet(u(7),:);
else
%
% When selector is AUTO DIFFERENTIAL KINEMATICS is applied.
% from Inverse DK we get the incremental joint coordinates
% and then integrating with EULER Explicit Method the Theta VALUE 
% with the new joint positions vector (1x7) OUTPUT.
% consider the integration step size.
    ThetaVALnew = ThetaVAL + (Thetap * stamp);
%
end
%
% The Theta POSITION values are limited by the joints position limits.
for i = 1:7
    ThetaVALnew(i) = jointmag2limits(ThetaVALnew(i), Thmax(i), Thmin(i), "rot");
end
%
% For some Target REFERENCE out of the workspace, the Theta VALUE can get
% some huge incorrect values. To avoid these kind of problems, we implement 
% a check loop to select the solution with the better approximation to the
% Target REFERENCE POSITION. The new or the previous Theta VALUE.
TwMagnew = [Twist; ThetaVALnew];
HstThenew = ForwardKinematicsPOE(TwMagnew)*Hst0;
TargetVALnew = [HstThenew(1:3,4)' rotm2eul(HstThenew(1:3,1:3), 'XYZ')];
TcP1dist = minusposeEul(TargetVAL, TargetREF);
TcP2dist = minusposeEul(TargetVALnew, TargetREF);
if norm(TcP1dist(1:3)) <  norm(TcP2dist(1:3))
    ThetaVALnew = ThetaVAL; 
end
%
%
% Theta VALUE is the new joint positions vector (1x7) OUTPUT
ThetaVAL = ThetaVALnew;
ThetapVAL = Thetap;
ThetaOut = [ThetaVAL ThetapVAL Thetapp];
%
end
%